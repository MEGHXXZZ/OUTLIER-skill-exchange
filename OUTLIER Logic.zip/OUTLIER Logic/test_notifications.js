const notifs = require('./notifications');
console.log("✅ Notifications module loaded!");
console.log("Available functions:");
console.log("- notifyTeacherNewLearner");
console.log("- sendCancellationAlert");
console.log("- notifyRescueMatch");
console.log("- sendSessionReminder");