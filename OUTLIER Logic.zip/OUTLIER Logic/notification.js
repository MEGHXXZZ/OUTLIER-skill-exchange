// ==========================================
// OUTLIER - NOTIFICATION SYSTEM
// Uses Firebase Admin SDK (v11+ syntax)
// ==========================================

const { initializeApp, cert } = require('firebase-admin/app');
const { getMessaging } = require('firebase-admin/messaging');
const serviceAccount = require('./serviceAccountKey.json');

// Initialize Firebase
initializeApp({
    credential: cert(serviceAccount)
});

// ==========================================
// 1. NOTIFY TEACHER WHEN A LEARNER WANTS THEIR SKILL
// ==========================================
function notifyTeacherNewLearner(teacherFcmToken, learnerName, skill) {
    const message = {
        token: teacherFcmToken,
        notification: {
            title: "New Learner Request! 🎓",
            body: learnerName + " wants to learn " + skill + " from you."
        },
        data: {
            type: "NEW_LEARNER",
            skill: skill,
            learnerName: learnerName
        }
    };

    return getMessaging().send(message);
}

// ==========================================
// 2. SEND CANCELLATION ALERT
// ==========================================
function sendCancellationAlert(userFcmToken, otherUserName, timeSlot) {
    const message = {
        token: userFcmToken,
        notification: {
            title: "⚠️ Session Cancelled",
            body: otherUserName + " cancelled your session at " + timeSlot
        },
        data: {
            type: "CANCELLATION",
            timeSlot: timeSlot
        }
    };

    return getMessaging().send(message);
}

// ==========================================
// 3. NOTIFY RESCUE MATCH FOUND
// ==========================================
function notifyRescueMatch(userFcmToken, replacementName, skill) {
    const message = {
        token: userFcmToken,
        notification: {
            title: "🎉 Rescue Match Found!",
            body: replacementName + " is available to teach " + skill + " right now!"
        },
        data: {
            type: "RESCUE_MATCH",
            skill: skill,
            replacementName: replacementName
        }
    };

    return getMessaging().send(message);
}

// ==========================================
// 4. SESSION REMINDER (15 min before)
// ==========================================
function sendSessionReminder(userFcmToken, otherUserName, skill, timeSlot) {
    const message = {
        token: userFcmToken,
        notification: {
            title: "⏰ Session in 15 Minutes",
            body: otherUserName + " will teach you " + skill + " at " + timeSlot
        },
        data: {
            type: "REMINDER",
            skill: skill,
            timeSlot: timeSlot
        }
    };

    return getMessaging().send(message);
}

// ==========================================
// EXPORT
// ==========================================
module.exports = {
    notifyTeacherNewLearner: notifyTeacherNewLearner,
    sendCancellationAlert: sendCancellationAlert,
    notifyRescueMatch: notifyRescueMatch,
    sendSessionReminder: sendSessionReminder
};