// ==========================================
// COMMUNITY SKILL CIRCLES LOGIC
// One teacher, many learners
// ==========================================

// Create a new Circle (teacher action)
function createCircle(teacherId, skill, maxLearners, day, startTime, endTime) {
    return {
        circleId: "CIRCLE_" + Date.now(),
        teacherId: teacherId,
        skill: skill,
        maxLearners: maxLearners,
        currentLearners: 0,
        learners: [],
        schedule: {
            day: day,
            startTime: startTime,
            endTime: endTime
        },
        status: "OPEN",
        contributions: {},
        createdAt: new Date().toISOString()
    };
}

// Join a Circle (learner action)
function joinCircle(circle, learnerId) {
    if (circle.status !== "OPEN") {
        return { success: false, message: "Circle is closed." };
    }
    if (circle.currentLearners >= circle.maxLearners) {
        return { success: false, message: "Circle is full." };
    }
    if (circle.learners.includes(learnerId)) {
        return { success: false, message: "You are already in this circle." };
    }

    circle.learners.push(learnerId);
    circle.currentLearners = circle.learners.length;

    if (circle.currentLearners >= circle.maxLearners) {
        circle.status = "FULL";
    }

    return { success: true, message: "Joined successfully!", circle: circle };
}

// Track Contribution (called after each session)
function trackContribution(circle, learnerId, contributionScore) {
    if (!circle.contributions) {
        circle.contributions = {};
    }
    if (!circle.contributions[learnerId]) {
        circle.contributions[learnerId] = [];
    }

    circle.contributions[learnerId].push(contributionScore);
    return circle;
}

// Export
module.exports = {
    createCircle: createCircle,
    joinCircle: joinCircle,
    trackContribution: trackContribution
};