const logic = require('./logic');

let meghavathi = {
    name: "Meghavathi",
    skillsToTeach: [{ skill: "Graphic Design", level: "Advanced" }],
    skillsToLearn: ["Web Development", "Python"],
    availability: [{ day: "Saturday", startTime: "10:00", endTime: "12:00" }],
    location: { city: "Chikkamagaluru" },
    reliabilityScore: 90
};

let mohan = {
    name: "Mohan",
    skillsToTeach: [{ skill: "Web Development", level: "Advanced" }],
    skillsToLearn: ["Graphic Design"],
    availability: [{ day: "Saturday", startTime: "10:00", endTime: "12:00" }],
    location: { city: "Chikkamagaluru" },
    reliabilityScore: 95
};

let jaswith = {
    name: "Jaswith",
    skillsToTeach: [{ skill: "Python", level: "Intermediate" }],
    skillsToLearn: ["Graphic Design"],
    availability: [{ day: "Sunday", startTime: "14:00", endTime: "16:00" }],
    location: { city: "Mysore" },
    reliabilityScore: 70
};

let allUsers = [mohan, jaswith];

console.log("--- TEST 1: SMART MATCHING ---");
console.log("Looking for matches for:", meghavathi.name);
let myMatches = logic.getMatches(meghavathi, allUsers);
for (let i = 0; i < myMatches.length; i++) {
    console.log("Match Found: " + myMatches[i].name + " | Score: " + myMatches[i].matchScore);
}

console.log("\n--- TEST 2: RESCUE MATCH ---");
console.log("Meghavathi's Web Development session was cancelled on Saturday 10:00");
let rescues = logic.rescueMatch("Web Development", "Saturday", "10:00", allUsers);
console.log("Found " + rescues.length + " rescue replacement(s).");
for (let i = 0; i < rescues.length; i++) {
    console.log("Rescue Match: " + rescues[i].name);
}

console.log("\n--- TEST 3: RELIABILITY SCORE ---");
console.log("Meghavathi's current score: " + meghavathi.reliabilityScore);
let newScore = logic.updateReliabilityScore(meghavathi.reliabilityScore, 'CANCELLED_LAST_MINUTE');
console.log("After cancelling last minute: " + newScore);
let recoveredScore = logic.updateReliabilityScore(newScore, 'COMPLETED_SESSION');
console.log("After completing a session: " + recoveredScore);