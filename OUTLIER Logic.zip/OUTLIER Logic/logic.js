const notifs = require('./notifications');
// ==========================================
// HOW TO USE THIS FILE IN YOUR BACKEND:
// 
// 1. Copy this file into your backend routes folder.
// 2. At the top of your API file, add:
//    const logic = require('./logic');
// 3. Inside your API route, call:
//    const matches = logic.getMatches(req.user, allUsers);
//    res.json(matches);
// 4. For Rescue Match:
//    const replacements = logic.rescueMatch(skill, day, time, allUsers);
// 5. For Reliability Score:
//    const newScore = logic.updateReliabilityScore(user.score, 'CANCELLED_LAST_MINUTE');
// ==========================================
// ==========================================
// OUTLIER - MATCHING ENGINE
// Written by Jeevika
// ==========================================

function getMatches(currentUser, allOtherUsers) {
    let matches = [];
    for (let i = 0; i < allOtherUsers.length; i++) {
        let otherUser = allOtherUsers[i];
        let theyTeachWhatIWant = false;
        for (let j = 0; j < currentUser.skillsToLearn.length; j++) {
            for (let k = 0; k < otherUser.skillsToTeach.length; k++) {
                if (currentUser.skillsToLearn[j] === otherUser.skillsToTeach[k].skill) {
                    theyTeachWhatIWant = true;
                }
            }
        }
        let iTeachWhatTheyWant = false;
        for (let j = 0; j < otherUser.skillsToLearn.length; j++) {
            for (let k = 0; k < currentUser.skillsToTeach.length; k++) {
                if (otherUser.skillsToLearn[j] === currentUser.skillsToTeach[k].skill) {
                    iTeachWhatTheyWant = true;
                }
            }
        }
        if (theyTeachWhatIWant && iTeachWhatTheyWant) {
            let score = 50;
            if (currentUser.location.city === otherUser.location.city) {
                score = score + 20;
            }
            if (otherUser.reliabilityScore > 80) {
                score = score + 30;
            }
            matches.push({
                name: otherUser.name,
                matchScore: score,
                teaches: otherUser.skillsToTeach,
                wantsToLearn: otherUser.skillsToLearn
            });
        }
    }
    matches.sort(function(a, b) { return b.matchScore - a.matchScore; });
    return matches;
}

function rescueMatch(cancelledSkill, cancelledDay, cancelledTime, allUsers) {
    let replacements = [];
    for (let i = 0; i < allUsers.length; i++) {
        let user = allUsers[i];
        let teachesSkill = false;
        for (let j = 0; j < user.skillsToTeach.length; j++) {
            if (user.skillsToTeach[j].skill === cancelledSkill) {
                teachesSkill = true;
            }
        }
        let isAvailable = false;
        for (let j = 0; j < user.availability.length; j++) {
            let slot = user.availability[j];
            if (slot.day === cancelledDay && slot.startTime === cancelledTime) {
                isAvailable = true;
            }
        }
        let isReliable = user.reliabilityScore > 80;
                if (teachesSkill && isAvailable && isReliable) {
            replacements.push(user);
        }
    }

    // Notify user if a rescue replacement is found
    if (replacements.length > 0) {
        console.log("🔔 Rescue Match found! Notifying user about:", replacements[0].name);
        // Uncomment the line below once real FCM tokens are available:
        // notifs.notifyRescueMatch(userFcmToken, replacements[0].name, cancelledSkill);
    }

    return replacements;
}
function updateReliabilityScore(currentScore, action) {
    let newScore = currentScore;
    if (action === 'CANCELLED_LAST_MINUTE') {
        newScore = newScore - 20;
        if (newScore < 0) newScore = 0;
    } else if (action === 'COMPLETED_SESSION') {
        newScore = newScore + 5;
        if (newScore > 100) newScore = 100;
    }
    return newScore;
}

module.exports = {
    getMatches: getMatches,
    rescueMatch: rescueMatch,
    updateReliabilityScore: updateReliabilityScore
};