// ==========================================
// OUTLIER - NOTIFICATION SYSTEM
// ==========================================

const { initializeApp, cert } = require('firebase-admin/app');
const { getMessaging } = require('firebase-admin/messaging');
const serviceAccount = require('./serviceAccountKey.json');

initializeApp({
    credential: cert(serviceAccount)
});

function notifyTeacherNewLearner(teacherFcmToken, learnerName, skill) {
    const message = {
        token: teacherFcmToken,
        notification: {
            title: "New Learner Request! 🎓",
            body: learnerName + " wants to learn " + skill + " from you."
        },
        data: { type: "NEW_LEARNER", skill: skill, learnerName: learnerName }
    };
    return getMessaging().send(message);
}

function sendCancellationAlert(userFcmToken, otherUserName, timeSlot) {
    const message = {
        token: userFcmToken,
        notification: {
            title: "⚠️ Session Cancelled",
            body: otherUserName + " cancelled your session at " + timeSlot
        },
        data: { type: "CANCELLATION", timeSlot: timeSlot }
    };
    return getMessaging().send(message);
}

function notifyRescueMatch(userFcmToken, replacementName, skill) {
    const message = {
        token: userFcmToken,
        notification: {
            title: "🎉 Rescue Match Found!",
            body: replacementName + " is available to teach " + skill + " right now!"
        },
        data: { type: "RESCUE_MATCH", skill: skill, replacementName: replacementName }
    };
    return getMessaging().send(message);
}

function sendSessionReminder(userFcmToken, otherUserName, skill, timeSlot) {
    const message = {
        token: userFcmToken,
        notification: {
            title: "⏰ Session in 15 Minutes",
            body: otherUserName + " will teach you " + skill + " at " + timeSlot
        },
        data: { type: "REMINDER", skill: skill, timeSlot: timeSlot }
    };
    return getMessaging().send(message);
}

module.exports = {
    notifyTeacherNewLearner: notifyTeacherNewLearner,
    sendCancellationAlert: sendCancellationAlert,
    notifyRescueMatch: notifyRescueMatch,
    sendSessionReminder: sendSessionReminder
};