// ==========================================
// DUMMY USERS FOR TESTING
// ==========================================

const dummyUsers = [
    {
        _id: "u001",
        name: "Meghavathi",
        email: "megha@outlier.com",
        skillsToTeach: [{ skill: "Graphic Design", level: "Advanced" }],
        skillsToLearn: ["Web Development"],
        availability: [{ day: "Saturday", startTime: "10:00", endTime: "12:00" }],
        location: { city: "Chikkamagaluru" },
        reliabilityScore: 90,
        preferences: { sessionType: "Face", genderFilter: "None" }
    },
    {
        _id: "u002",
        name: "Mohan",
        email: "mohan@outlier.com",
        skillsToTeach: [{ skill: "Web Development", level: "Advanced" }],
        skillsToLearn: ["Graphic Design"],
        availability: [{ day: "Saturday", startTime: "10:00", endTime: "12:00" }],
        location: { city: "Chikkamagaluru" },
        reliabilityScore: 95,
        preferences: { sessionType: "Face", genderFilter: "None" }
    },
    {
        _id: "u003",
        name: "Jaswith",
        email: "jaswith@outlier.com",
        skillsToTeach: [{ skill: "Python", level: "Intermediate" }],
        skillsToLearn: ["Graphic Design"],
        availability: [{ day: "Sunday", startTime: "14:00", endTime: "16:00" }],
        location: { city: "Mysore" },
        reliabilityScore: 70,
        preferences: { sessionType: "Faceless", genderFilter: "None" }
    }
];

module.exports = dummyUsers;