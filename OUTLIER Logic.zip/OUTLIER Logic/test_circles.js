const circles = require('./circles');

console.log("--- TEST: CREATE CIRCLE ---");
let webDevCircle = circles.createCircle("user_001", "Web Development", 3, "Saturday", "10:00", "12:00");
console.log("Circle created:", webDevCircle.circleId);
console.log("Skill:", webDevCircle.skill, "| Max Learners:", webDevCircle.maxLearners);

console.log("\n--- TEST: JOIN CIRCLE ---");
let join1 = circles.joinCircle(webDevCircle, "learner_A");
console.log(join1.message, "| Current learners:", webDevCircle.currentLearners);

let join2 = circles.joinCircle(webDevCircle, "learner_B");
console.log(join2.message, "| Current learners:", webDevCircle.currentLearners);

let join3 = circles.joinCircle(webDevCircle, "learner_C");
console.log(join3.message, "| Current learners:", webDevCircle.currentLearners);

let join4 = circles.joinCircle(webDevCircle, "learner_D");
console.log(join4.message);

console.log("\n--- TEST: TRACK CONTRIBUTION ---");
circles.trackContribution(webDevCircle, "learner_A", 8);
circles.trackContribution(webDevCircle, "learner_A", 9);
circles.trackContribution(webDevCircle, "learner_B", 7);
console.log("Contributions for learner_A:", webDevCircle.contributions["learner_A"]);
console.log("Contributions for learner_B:", webDevCircle.contributions["learner_B"]);