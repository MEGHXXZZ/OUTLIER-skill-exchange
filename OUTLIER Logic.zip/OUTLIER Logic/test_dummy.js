const dummyUsers = require('./dummyUsers');
console.log("Total dummy users:", dummyUsers.length);
console.log("Names:", dummyUsers.map(u => u.name).join(", "));