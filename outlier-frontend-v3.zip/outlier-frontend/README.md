# OUTLIER Frontend (Team CBC064)

## Run
    npm install
    npm run dev
Open http://localhost:5173  (use localhost, NOT the 172.x network address:
camera, microphone and screen sharing are blocked by browsers on plain http network addresses)

## Demo flow
1. Sign in (demo account Meghavathi) -> Dashboard
   or Create an account -> Onboarding (skills, availability, city, preferences) -> Dashboard
2. Dashboard: "Add a skill" / "Take quiz" runs the 3-question verification (pass = 2 of 3)
3. Find Match: ranked by Jeevika's matching rules (src/matching.js, data in src/dummyUsers.js)
4. Sessions:
   - Join session opens the live room (camera, mic, speaker, screen share). End session unlocks Check in.
   - Cancel is only allowed 30+ minutes before the start.
       Web Development with Kayashree (3 h away): cancel -> Rescue Match finds a replacement
       React.js with Arjun (1 day away): cancel -> no replacement, alternative slots
       Data Science with Sneha (20 min away): cancel is blocked
5. Circles: search, join, create

## Backend hookup
Fake data: src/mockData.js and src/dummyUsers.js. App state: src/store.jsx. API helpers: src/api.js.
On different laptops use the backend's LAN IP in src/api.js instead of localhost.
Partner video in the live room is a placeholder until a real call service (WebRTC) is connected.

## Skill tests, gender filter and profiles

- **Add a skill** (Dashboard): suggestions grouped by area, or type any topic. Each test has 12 shuffled questions and needs 70% (9/12) to pass. Questions live in `src/quizBank.js`; add a skill there to make it testable.
- **Topics without a test:** the app calls `POST /verify/questions` (see `api.js`) expecting `{ questions: [{ q, options, answer }] }` with 10-15 items. If the backend is not available the member can save the topic under "Awaiting verification".
- **Find Match:** Men / Women / Any filter under the search box. Starts from the preference chosen in onboarding.
- **Profiles:** every user name links to `/profile/:id` (`/profile/me` for yourself). Directory data is in `src/dummyUsers.js`.
