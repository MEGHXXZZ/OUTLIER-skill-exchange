import { createContext, useContext, useRef, useState } from 'react';
import { mockUser, mockCircles, makeInitialSessions, initialHistory } from './mockData';

const AppContext = createContext(null);
const DAY = 24 * 3600e3;

const blankUser = (name, email) => ({
  id: 'me', name, email, isVerified: false,
  preference: 'Face-to-Face', genderFilter: 'Any',
  city: '', skillsToLearn: [], availability: [], teachLevel: {},
  learnt: [], ongoing: [], teaching: [], pendingTeach: [], badges: [],
  reliability: 100, streak: 0,
});

export function AppProvider({ children }) {
  const [user, setUser] = useState({ ...mockUser });
  const [sessions, setSessions] = useState(makeInitialSessions);
  const [history, setHistory] = useState(initialHistory);
  const [circles, setCircles] = useState(mockCircles.map((c) => ({ ...c, joined: false })));
  // Exchange requests: { id, matchId, name, skill, slot, mode, status: 'pending' | 'accepted' | 'declined' }
  const [requests, setRequests] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const pendingIds = useRef(new Set()); // requests still waiting for an answer
  const [toast, setToast] = useState(null);

  const notify = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2800);
  };

  const pushNotification = (text, kind = 'info') =>
    setNotifications((n) => [{ id: Date.now() + Math.random(), text, kind, read: false, at: Date.now() }, ...n].slice(0, 20));

  const markNotificationsRead = () => setNotifications((n) => n.map((x) => (x.read ? x : { ...x, read: true })));

  const resetExchanges = () => {
    pendingIds.current.clear();
    setRequests([]);
    setNotifications([]);
  };

  const log = (skill, partner, status, note = '') =>
    setHistory((h) => [{ id: Date.now() + Math.random(), skill, partner, note, status, when: 'Just now' }, ...h]);

  // ---- accounts (frontend demo only; the backend will own real auth) ----
  const signIn = () => {
    setUser({ ...mockUser });
    setSessions(makeInitialSessions());
    setHistory(initialHistory);
    resetExchanges();
  };

  const signUp = ({ name, email }) => {
    setUser(blankUser(name, email));
    setSessions([]);
    setHistory([]);
    resetExchanges();
  };

  const updateProfile = (patch) => setUser((u) => ({ ...u, ...patch }));

  // ---- exchanges and sessions ----
  const getRequest = (matchId) => requests.find((r) => r.matchId === matchId);

  // Stand-in for the other member's reply. The backend will deliver the real answer later.
  const respondToRequest = (req) => {
    if (!pendingIds.current.has(req.id)) return; // withdrawn in the meantime
    pendingIds.current.delete(req.id);
    const accepted = Math.random() < 0.75;
    setRequests((rs) => rs.map((r) => (r.id === req.id ? { ...r, status: accepted ? 'accepted' : 'declined' } : r)));
    if (accepted) {
      setSessions((s) => [
        ...s,
        { id: Date.now(), partner: req.name, skill: req.skill, slot: req.slot, mode: req.mode, type: '1-on-1', startsAt: Date.now() + DAY, status: 'upcoming' },
      ]);
      log(req.skill, req.name, 'Scheduled');
      pushNotification(`${req.name} accepted your request. ${req.skill} is now scheduled.`, 'accepted');
      notify(`${req.name} accepted your request`);
    } else {
      log(req.skill, req.name, 'Declined');
      pushNotification(`${req.name} declined your ${req.skill} request. Try again or find another match.`, 'declined');
      notify(`${req.name} declined your request`);
    }
  };

  // Sending a request no longer books anything. The session is created only once the other member accepts.
  const requestExchange = (match, mode = 'Face-to-Face') => {
    const existing = getRequest(match.id);
    if (existing && existing.status !== 'declined') return; // a declined request can be sent again
    const req = {
      id: Date.now() + Math.random(),
      matchId: match.id, name: match.name, skill: match.teaches, slot: match.availability, mode, status: 'pending',
    };
    pendingIds.current.add(req.id);
    setRequests((r) => [...r.filter((x) => x.matchId !== match.id), req]);
    notify(`Request sent to ${match.name}. Waiting for approval`);
    setTimeout(() => respondToRequest(req), 4000 + Math.random() * 3000);
  };

  const withdrawRequest = (id) => {
    pendingIds.current.delete(id);
    setRequests((r) => r.filter((x) => x.id !== id));
    notify('Request withdrawn');
  };

  const cancelSession = (id, reason) => {
    const s = sessions.find((x) => x.id === id);
    if (!s) return;
    setSessions((list) => list.filter((x) => x.id !== id));
    log(s.skill, s.partner, 'Cancelled', reason);
    setUser((u) => ({ ...u, reliability: Math.max(0, u.reliability - 2) }));
  };

  const rescueSession = (match) => {
    setSessions((list) => [
      ...list,
      { id: Date.now(), partner: match.name, skill: match.skill, slot: match.slot, mode: 'Face-to-Face', type: '1-on-1', startsAt: Date.now() + DAY, status: 'upcoming' },
    ]);
    log(match.skill, match.name, 'Rescued');
    notify(`Rescue request sent to ${match.name}`);
  };

  const rescheduleSession = (session, slot) => {
    setSessions((list) => [...list, { ...session, id: Date.now(), slot, startsAt: Date.now() + DAY, status: 'upcoming' }]);
    log(session.skill, session.partner, 'Rescheduled', `moved to ${slot}`);
    notify('Session rescheduled');
  };

  // Ending a live session unlocks check-in. Check-in is never available before the end.
  const endSession = (id) => {
    setSessions((list) => list.map((x) => (x.id === id ? { ...x, status: 'ended' } : x)));
    notify('Session ended. Check in to confirm your attendance.');
  };

  const checkIn = (id) => {
    const s = sessions.find((x) => x.id === id);
    if (!s || s.status !== 'ended') return;
    setSessions((list) => list.filter((x) => x.id !== id));
    log(s.skill, s.partner, 'Completed');
    setUser((u) => ({
      ...u,
      learnt: u.learnt.includes(s.skill) ? u.learnt : [...u.learnt, s.skill],
      ongoing: u.ongoing.filter((k) => k !== s.skill),
      badges: u.badges.includes(`${s.skill} Basics`) ? u.badges : [...u.badges, `${s.skill} Basics`],
      streak: u.streak + 1,
    }));
    notify('Attendance confirmed. New badge earned.');
  };

  const addVerifiedSkill = (skill) => {
    setUser((u) => ({
      ...u,
      teaching: u.teaching.includes(skill) ? u.teaching : [...u.teaching, skill],
      pendingTeach: u.pendingTeach.filter((k) => k !== skill),
      teachLevel: { ...u.teachLevel, [skill]: 'Intermediate' },
    }));
    notify(`${skill} verified and added to your profile`);
  };

  // A topic we have no test for yet: keep it on the dashboard so the member can verify it later.
  const addPendingSkill = (skill) => {
    setUser((u) => (u.teaching.includes(skill) || u.pendingTeach.includes(skill) ? u : { ...u, pendingTeach: [...u.pendingTeach, skill] }));
    notify(`${skill} saved under Awaiting verification`);
  };

  // ---- circles ----
  const joinCircle = (id) => {
    setCircles((list) =>
      list.map((c) => (c.id === id && !c.joined && c.members < c.maxMembers ? { ...c, joined: true, members: c.members + 1 } : c))
    );
    notify('You joined the circle');
  };

  const createCircle = (circle) => {
    setCircles((list) => [
      { id: Date.now(), teacher: user.name, members: 1, isVerified: true, joined: true, ...circle, maxMembers: Number(circle.maxMembers) || 5 },
      ...list,
    ]);
    notify('Circle created');
  };

  return (
    <AppContext.Provider
      value={{
        user, sessions, history, circles, requests, notifications, toast,
        signIn, signUp, updateProfile,
        requestExchange, withdrawRequest, getRequest, markNotificationsRead, cancelSession, rescueSession, rescheduleSession,
        endSession, checkIn, addVerifiedSkill, addPendingSkill, joinCircle, createCircle, notify,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export const useApp = () => useContext(AppContext);
