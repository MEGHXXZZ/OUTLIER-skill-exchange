import axios from 'axios';

// Change baseURL to the backend machine's LAN IP if running on different laptops,
// e.g. http://192.168.1.15:5000/api
const API = axios.create({ baseURL: 'http://localhost:5000/api' });

export const login = (data) => API.post('/auth/login', data);
export const getMatches = () => API.get('/match');
export const createSession = (data) => API.post('/sessions', data);
export const cancelSession = (id, reason) => API.put(`/sessions/${id}/cancel`, { reason });
export const rescheduleSession = (id, slot) => API.put(`/sessions/${id}/reschedule`, { slot });
// Optional: backend can generate 10-15 questions for a topic we have no local test for.
// Expected reply: { questions: [{ q, options: [..], answer: <index> }] }
export const generateQuiz = (topic) => API.post('/verify/questions', { topic }, { timeout: 5000 });
export const verifySkill = (data) => API.post('/verify', data);
export const getCircles = () => API.get('/circles');
export const joinCircle = (id) => API.post(`/circles/${id}/join`);

export default API;
