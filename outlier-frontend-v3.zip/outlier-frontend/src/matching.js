import dummyUsers from './dummyUsers';

const toMin = (t) => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
const fmt = (t) => t;
const norm = (s) => s.trim().toLowerCase();

// Does any window of A overlap any window of B on the same day?
function availabilityScore(a, b) {
  let sameDay = false;
  for (const x of a) for (const y of b) {
    if (x.day !== y.day) continue;
    sameDay = true;
    if (toMin(x.startTime) < toMin(y.endTime) && toMin(y.startTime) < toMin(x.endTime)) {
      return { points: 25, label: 'Same time slot', slot: `${y.day} ${fmt(y.startTime)}-${fmt(y.endTime)}` };
    }
  }
  return { points: sameDay ? 10 : 0, label: sameDay ? 'Same day, different time' : 'Different days' };
}

/**
 * Rank other users for `me` by:
 *  - complementary skills (50 mutual / 25 one-way)
 *  - availability overlap (25)
 *  - same city (15)
 *  - reliability (10)
 * Users with no skill overlap in either direction are dropped.
 */
export function findMatches(me, users = dummyUsers) {
  const myTeach = me.skillsToTeach.map((s) => norm(s.skill));
  const myLearn = me.skillsToLearn.map(norm);

  return users
    .filter((u) => u._id !== me._id)
    .map((u) => {
      const theirTeach = u.skillsToTeach.map((s) => norm(s.skill));
      const theirLearn = u.skillsToLearn.map(norm);

      const iLearnFromThem = u.skillsToTeach.find((s) => myLearn.includes(norm(s.skill)));
      const theyLearnFromMe = me.skillsToTeach.find((s) => theirLearn.includes(norm(s.skill)));
      if (!iLearnFromThem && !theyLearnFromMe) return null;

      const mutual = !!(iLearnFromThem && theyLearnFromMe);
      const skillPts = mutual ? 50 : 25;
      const avail = availabilityScore(me.availability, u.availability);
      const sameCity = norm(me.location.city) === norm(u.location.city);
      const locPts = sameCity ? 15 : 0;
      const relPts = (u.reliabilityScore / 100) * 10;

      const score = Math.min(99, Math.round(skillPts + avail.points + locPts + relPts));
      const teachSkill = iLearnFromThem || u.skillsToTeach[0];
      const firstWindow = u.availability[0];

      return {
        id: u._id,
        name: u.name,
        gender: u.gender,
        teaches: teachSkill.skill,
        level: teachSkill.level,
        wants: u.skillsToLearn.join(', '),
        matchScore: score,
        availability: avail.slot || `${firstWindow.day} ${firstWindow.startTime}-${firstWindow.endTime}`,
        location: u.location.city,
        reliability: u.reliabilityScore,
        canBeFaceless: u.preferences.sessionType === 'Faceless',
        mutual,
        reasons: [
          mutual ? 'Mutual skill swap' : iLearnFromThem ? 'They teach what you want' : 'They want what you teach',
          avail.label,
          sameCity ? 'Same city' : 'Different city',
        ],
      };
    })
    .filter(Boolean)
    .sort((a, b) => b.matchScore - a.matchScore);
}

// The signed-in user for the demo is Meghavathi (u001).
export const currentUser = dummyUsers.find((u) => u._id === 'u001');

// Build the matching profile from the signed-in user's own account.
export function toMatchProfile(user) {
  return {
    _id: user.id || 'me',
    name: user.name,
    skillsToTeach: user.teaching.map((skill) => ({ skill, level: (user.teachLevel && user.teachLevel[skill]) || 'Intermediate' })),
    skillsToLearn: user.skillsToLearn || [],
    availability: user.availability || [],
    location: { city: user.city || '' },
    reliabilityScore: user.reliability,
    preferences: { sessionType: user.preference === 'Faceless' ? 'Faceless' : 'Face' },
  };
}
