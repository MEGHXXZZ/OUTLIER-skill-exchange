// Skill verification question bank.
// Each question is [question, [options], indexOfCorrectOption].
// buildQuiz() shuffles question order AND option order on every attempt,
// so the position of the right answer changes each time.

const RAW = {
  'Web Development': [
    ['Which HTML element is the most appropriate for a page\'s main navigation links?', ['<nav>', '<menu>', '<aside>', '<section>'], 0],
    ['In the CSS box model, what is the order from the inside out?', ['Content, padding, border, margin', 'Content, margin, border, padding', 'Content, border, padding, margin', 'Padding, content, border, margin'], 0],
    ['What does box-sizing: border-box change?', ['Width and height include padding and border', 'Margin is included in the width', 'The border is removed', 'Overflowing content is hidden'], 0],
    ['Which HTTP status code means the requested resource was not found?', ['200', '301', '404', '500'], 2],
    ['What is the alt attribute on an <img> mainly for?', ['Text for screen readers and for when the image fails to load', 'A tooltip shown on hover', 'Aligning the image', 'Setting the image size'], 0],
    ['Which CSS rule applies styles only on screens up to 600px wide?', ['@media (max-width: 600px) { ... }', '@screen small { ... }', '@responsive(600px) { ... }', '@viewport { max: 600px }'], 0],
    ['What does document.querySelector(".card") return?', ['The first element matching the selector', 'An array of every match', 'The text inside the element', 'A live HTMLCollection'], 0],
    ['Which HTTP method is conventionally used to create a new resource?', ['GET', 'POST', 'DELETE', 'OPTIONS'], 1],
    ['What is CORS?', ['A browser mechanism controlling which other origins may request a server\'s resources', 'A CSS layout module', 'A JavaScript bundler', 'A database query language'], 0],
    ['Which selector has the highest specificity?', ['#header', '.header', 'header', '*'], 0],
    ['What does the defer attribute on a <script> tag do?', ['Downloads in parallel and runs after the HTML is parsed', 'Runs the script before any HTML is parsed', 'Stops the script from ever running', 'Runs the script only on mobile'], 0],
    ['Which element is meant for self-contained content such as a blog post?', ['<article>', '<div>', '<span>', '<b>'], 0],
  ],

  'JavaScript': [
    ['What does typeof null return?', ['"object"', '"null"', '"undefined"', '"number"'], 0],
    ['What does [1, 2, 3].map(x => x * 2) return?', ['A new array [2, 4, 6]', 'The number 12', 'The original array, modified', 'undefined'], 0],
    ['What is the difference between == and ===?', ['=== compares without type coercion', '=== only works on numbers', '== is faster in every case', 'There is no difference'], 0],
    ['What is a closure?', ['A function that keeps access to variables from its outer scope', 'A way to close the browser tab', 'A function with no parameters', 'A block that cannot throw errors'], 0],
    ['Which declaration creates a binding that cannot be reassigned?', ['const', 'let', 'var', 'static'], 0],
    ['What does await do inside an async function?', ['Pauses that function until the Promise settles, without blocking the main thread', 'Blocks the whole browser until done', 'Cancels the Promise', 'Runs the code on a new thread'], 0],
    ['What does console.log(0.1 + 0.2 === 0.3) print?', ['false', 'true', 'undefined', 'It throws an error'], 0],
    ['Which method adds an item to the end of an array?', ['push()', 'pop()', 'shift()', 'unshift()'], 0],
    ['What does Array.prototype.filter return?', ['A new array of the items that pass the test', 'The first matching item', 'A boolean', 'The same array, modified'], 0],
    ['What is event bubbling?', ['An event travels from the target element up through its ancestors', 'An event travels only to child elements', 'Events are delayed until the page loads', 'Events fire twice'], 0],
    ['How does an arrow function treat this?', ['It inherits this from the surrounding scope', 'It always points to window', 'It creates a new this on each call', 'It is always undefined'], 0],
    ['What does JSON.parse do?', ['Converts a JSON string into a JavaScript value', 'Converts an object into a JSON string', 'Validates HTML', 'Sends data to a server'], 0],
  ],

  'React.js': [
    ['What does the useState hook return?', ['A pair: the current value and a function to update it', 'Only the current value', 'A promise', 'A reference to the DOM node'], 0],
    ['Why does each item in a rendered list need a stable key?', ['React uses it to track which items changed, were added or removed', 'It adds a CSS class', 'It makes the list sortable', 'It is only needed for tables'], 0],
    ['When does useEffect(() => { ... }, []) run?', ['After the first render only', 'After every render', 'Before the first render', 'Only when props change'], 0],
    ['How does a parent component pass data to a child?', ['Through props', 'Through global variables only', 'By calling the child\'s constructor', 'Through the key attribute'], 0],
    ['Why should you not mutate state directly (for example items.push(x))?', ['React may not detect the change, so the UI may not update', 'It throws a syntax error', 'It deletes the component', 'It is slower than setState'], 0],
    ['How do you embed a JavaScript expression inside JSX?', ['Wrap it in curly braces { }', 'Wrap it in double quotes', 'Use ${ } only', 'Use <script> tags'], 0],
    ['What is a controlled input?', ['An input whose value is driven by React state through value and onChange', 'An input that cannot be edited', 'An input with a validation library', 'An input rendered on the server'], 0],
    ['What is useRef commonly used for?', ['Holding a mutable value or DOM node that persists across renders without causing re-renders', 'Triggering a re-render', 'Fetching data', 'Styling components'], 0],
    ['How must a React component name be written to be used in JSX?', ['Starting with an uppercase letter', 'All lowercase', 'Ending with "Component"', 'With an underscore prefix'], 0],
    ['What does useMemo do?', ['Caches a computed value until its dependencies change', 'Stores data permanently in the browser', 'Fetches data from an API', 'Creates a new component'], 0],
    ['What does "lifting state up" mean?', ['Moving shared state to the closest common parent', 'Moving state to a database', 'Making state global with window', 'Deleting unused state'], 0],
    ['What problem does the Context API solve?', ['Sharing data across many levels without passing props through each one', 'Making components load faster', 'Routing between pages', 'Validating forms'], 0],
  ],

  'Python': [
    ['Which of these data types is immutable?', ['tuple', 'list', 'dict', 'set'], 0],
    ['What does len({1, 2, 2, 3}) return?', ['3', '4', '2', 'It raises an error'], 0],
    ['What does [x * x for x in range(4)] produce?', ['[0, 1, 4, 9]', '[1, 4, 9, 16]', '[0, 2, 4, 6]', '[0, 1, 2, 3]'], 0],
    ['In def f(a, b=2), what does b=2 mean?', ['b is optional and defaults to 2', 'b must always be 2', 'b is a keyword-only list', 'b is a constant'], 0],
    ['Which statements are used to handle exceptions?', ['try / except', 'catch / throw', 'if / error', 'handle / finally only'], 0],
    ['How does a set differ from a list?', ['A set holds unique, unordered items', 'A set keeps duplicates in order', 'A set can only hold numbers', 'A set is always sorted'], 0],
    ['What does "python"[::-1] return?', ['"nohtyp"', '"python"', '"p"', 'An error'], 0],
    ['What does with open("f.txt") as f: guarantee?', ['The file is closed automatically when the block ends', 'The file is created if it is missing', 'The file is read into memory instantly', 'The file is locked forever'], 0],
    ['What is the difference between is and ==?', ['is checks whether two names point to the same object; == checks equal values', 'They are identical', 'is compares only numbers', '== compares memory addresses'], 0],
    ['Which values does range(2, 10, 3) produce?', ['2, 5, 8', '2, 4, 6, 8', '2, 5, 8, 11', '3, 6, 9'], 0],
    ['What does d.get("k", 0) do when "k" is not in the dictionary d?', ['Returns 0', 'Raises KeyError', 'Adds "k" to d', 'Returns None'], 0],
    ['What does self represent inside a class method?', ['The instance the method was called on', 'The class itself', 'The parent class', 'The module'], 0],
  ],

  'Data Science': [
    ['Which Python library is most commonly used for tabular DataFrames?', ['pandas', 'flask', 'pygame', 'requests'], 0],
    ['What is overfitting?', ['A model memorises the training data and performs poorly on new data', 'A model is too simple to learn patterns', 'The dataset has missing values', 'Training takes too long'], 0],
    ['Which metric is typically used for a regression problem?', ['Mean squared error', 'Accuracy', 'F1 score', 'Confusion matrix'], 0],
    ['Why split data into training and test sets?', ['To evaluate the model on data it has not seen', 'To make training faster', 'To remove outliers', 'To balance the classes'], 0],
    ['Which measure of centre is least affected by outliers?', ['Median', 'Mean', 'Sum', 'Range'], 0],
    ['Which is an example of supervised learning?', ['Predicting house prices from labelled historical sales', 'Grouping customers with no labels', 'Reducing the number of features with no target', 'Finding unusual patterns with no labels'], 0],
    ['How is precision defined?', ['TP / (TP + FP)', 'TP / (TP + FN)', 'TN / (TN + FP)', '(TP + TN) / total'], 0],
    ['Why scale features before using k-nearest neighbours?', ['Distance is dominated by features with large numeric ranges', 'It makes the labels numeric', 'It removes missing values', 'It is required by pandas'], 0],
    ['Ice-cream sales and drownings are strongly correlated. What can you conclude?', ['Correlation alone does not prove causation; a third factor such as hot weather may drive both', 'Ice cream causes drowning', 'Drowning causes ice-cream sales', 'The data must be wrong'], 0],
    ['Which is a common way to handle missing numeric values?', ['Impute with the mean or median, or drop the rows if justified', 'Replace them with the word "missing"', 'Delete the whole dataset', 'Ignore them; models always handle them'], 0],
    ['A test gives p = 0.03. What does that mean?', ['If the null hypothesis were true, results this extreme would occur about 3% of the time', 'There is a 3% chance the null hypothesis is true', 'The effect size is 3%', 'The model is 97% accurate'], 0],
    ['What does k-fold cross-validation do?', ['Splits data into k parts and rotates which part is used for validation', 'Trains k different models on the same data and averages them', 'Removes k outliers', 'Creates k new features'], 0],
  ],

  'Excel': [
    ['Which formula adds the values in cells A1 to A10?', ['=SUM(A1:A10)', '=ADD(A1,A10)', '=TOTAL(A1:A10)', '=PLUS(A1:A10)'], 0],
    ['Which function finds a value in the first column of a range and returns a value from another column in the same row?', ['VLOOKUP', 'COUNTIF', 'CONCAT', 'ROUND'], 0],
    ['What does $A$1 mean when you copy the formula to other cells?', ['The reference stays fixed on A1', 'The reference shifts with the cell', 'The cell is locked from editing', 'The value is converted to currency'], 0],
    ['What does COUNTIF do?', ['Counts the cells that meet a condition', 'Counts every cell in the sheet', 'Adds numbers that meet a condition', 'Counts only blank cells'], 0],
    ['What is a PivotTable used for?', ['Summarising and grouping large data interactively', 'Drawing shapes', 'Encrypting a workbook', 'Spell-checking cells'], 0],
    ['What does =IF(B2>=50,"Pass","Fail") show when B2 contains 72?', ['Pass', 'Fail', '72', 'TRUE'], 0],
    ['Which feature keeps the header row visible while you scroll?', ['Freeze Panes', 'Merge Cells', 'Protect Sheet', 'Text to Columns'], 0],
    ['What does =SUMIF(A1:A4,">10",B1:B4) do?', ['Adds the B values whose matching A value is greater than 10', 'Adds all A values greater than 10 and B values together', 'Counts the A values greater than 10', 'Returns TRUE if any A value is greater than 10'], 0],
    ['What does the #DIV/0! error mean?', ['A formula tried to divide by zero', 'A cell reference is missing', 'A text value was used as a number', 'The column is too narrow'], 0],
    ['What does Data Validation let you do?', ['Restrict what can be entered in a cell, for example a dropdown list', 'Recover deleted sheets', 'Convert text to numbers', 'Sort data automatically'], 0],
    ['What does =A1&" "&B1 do?', ['Joins the text of A1 and B1 with a space between', 'Adds A1 and B1', 'Compares A1 and B1', 'Multiplies A1 and B1'], 0],
    ['What does Conditional Formatting do?', ['Formats cells automatically based on their values', 'Locks cells based on the user', 'Converts formulas to values', 'Hides rows with errors'], 0],
  ],

  'Graphic Design': [
    ['Which colour model should you use for a poster going to a commercial printer?', ['CMYK', 'RGB', 'HSL', 'Hex'], 0],
    ['What does kerning adjust?', ['The space between a specific pair of letters', 'The space between lines of text', 'The thickness of a font', 'The size of a font'], 0],
    ['What does leading control?', ['The vertical space between lines of text', 'The space between letters', 'The text colour', 'The paragraph indent'], 0],
    ['Which format is vector-based and scales without losing quality?', ['SVG', 'JPEG', 'PNG', 'BMP'], 0],
    ['Which common web image format does NOT support transparency?', ['JPEG', 'PNG', 'SVG', 'WebP'], 0],
    ['Which principle makes an element stand out through differences in colour, size or weight?', ['Contrast', 'Repetition', 'Alignment', 'Proximity'], 0],
    ['What is the rule of thirds?', ['Dividing a layout into a 3x3 grid and placing key elements along the lines or intersections', 'Using only three colours', 'Using three fonts per design', 'Making every element one third of the page'], 0],
    ['What resolution is the usual standard for print-quality images?', ['300 DPI', '72 DPI', '96 DPI', '30 DPI'], 0],
    ['What are complementary colours?', ['Colours opposite each other on the colour wheel', 'Colours next to each other on the wheel', 'Different shades of one colour', 'Black and white only'], 0],
    ['What is a serif?', ['A small stroke at the end of a letter\'s main strokes', 'A bold font weight', 'A type of image file', 'A grid system'], 0],
    ['What is the purpose of visual hierarchy?', ['To guide the viewer\'s eye in order of importance', 'To use as many styles as possible', 'To make everything the same size', 'To reduce file size'], 0],
    ['What is the main benefit of white (negative) space?', ['Improves readability and focus', 'Saves printing ink only', 'Makes the layout look unfinished', 'Lets you fit more text'], 0],
  ],

  'UI/UX Design': [
    ['What is a wireframe?', ['A low-fidelity layout sketch of a screen', 'A finished visual design', 'A coded prototype', 'A colour palette'], 0],
    ['Which Gestalt principle says related items should be placed close together?', ['Proximity', 'Contrast', 'Repetition', 'Symmetry'], 0],
    ['What does a usability test mainly measure?', ['How easily real users complete tasks', 'Server speed', 'Code quality', 'Colour accuracy'], 0],
    ['What is a user persona?', ['A fictional but research-based profile of a typical user', 'A real customer\'s login', 'A brand mascot', 'A test script'], 0],
    ['According to Fitts\'s law, which button is easiest to hit?', ['A larger one that is closer to the pointer', 'A tiny one far away', 'A hidden one in a menu', 'One that blinks'], 0],
    ['What does Hick\'s law say?', ['The more choices you offer, the longer people take to decide', 'People always prefer fewer pages', 'Bigger buttons are always better', 'Users read every word'], 0],
    ['What is the WCAG AA minimum contrast ratio for normal body text?', ['4.5 : 1', '2 : 1', '3.5 : 1', '10 : 1'], 0],
    ['What is an affordance?', ['A cue that suggests how an element can be used', 'A paid design feature', 'A loading animation', 'A type of grid'], 0],
    ['Which is a qualitative research method?', ['User interviews', 'Analytics page-view counts', 'Server logs', 'Conversion-rate formulas'], 0],
    ['What is a clickable prototype mainly used for?', ['Simulating flows to test interactions before development', 'Replacing the final product', 'Writing documentation', 'Choosing a database'], 0],
    ['What should a good empty state (a screen with no data yet) do?', ['Explain what is missing and guide the user to the next action', 'Stay completely blank', 'Show an error message', 'Redirect to the homepage'], 0],
    ['What is the purpose of an A/B test?', ['Comparing two versions to see which performs better', 'Testing two browsers', 'Checking grammar', 'Backing up designs'], 0],
  ],

  'Public Speaking': [
    ['What is the strongest way to open a talk?', ['A hook such as a story, question or surprising fact', 'Reading your slides aloud', 'Apologising for being nervous', 'Listing the full agenda in detail'], 0],
    ['How should slides be used?', ['To support what you say, not replace it', 'As a script to read word for word', 'To hold all your notes', 'To fill every second of silence'], 0],
    ['What helps most with pacing?', ['Short, deliberate pauses', 'Speaking faster', 'Never pausing', 'Reading straight through'], 0],
    ['Which habit most reliably reduces stage fright?', ['Rehearsing out loud several times', 'Memorising word for word', 'Avoiding practice so it feels natural', 'Skipping the introduction'], 0],
    ['What is good eye-contact technique in a room?', ['Hold contact with one person at a time for a full thought, moving around the room', 'Stare at the back wall', 'Look only at your notes', 'Glance quickly at everyone without settling'], 0],
    ['What is the "rule of three" in speaking?', ['Grouping points in threes makes them easier to remember', 'Speaking for exactly three minutes', 'Repeating every point three times', 'Using three slides per minute'], 0],
    ['What is the best replacement for filler words like "um" and "like"?', ['A silent pause', 'Speaking louder', 'A different filler word', 'Speaking faster'], 0],
    ['Which structure suits most talks?', ['Introduction with a preview, body, then a conclusion with a recap', 'Body only', 'Conclusion first, then nothing else', 'Random order for variety'], 0],
    ['What should you do when asked a question you cannot answer?', ['Admit it honestly and offer to follow up', 'Make up an answer', 'Ignore the question', 'Blame the audience member'], 0],
    ['Why analyse your audience before preparing a talk?', ['To tailor content, vocabulary and examples to what they know and need', 'To pick a slide template', 'To decide how long to talk by guessing', 'It is not necessary'], 0],
    ['Why is speaking in a monotone a problem?', ['Varied pitch, pace and volume keep the audience engaged', 'It makes you sound too confident', 'It tires the microphone', 'It shortens your talk'], 0],
    ['What should the final moments of a talk contain?', ['A clear takeaway or call to action', 'A new topic', 'An apology for running long', 'A long list of thanks only'], 0],
  ],

  'Photography': [
    ['Which three settings make up the exposure triangle?', ['Aperture, shutter speed and ISO', 'Zoom, flash and focus', 'Resolution, contrast and saturation', 'White balance, tint and tone'], 0],
    ['What effect does a wide aperture such as f/1.8 have?', ['Shallow depth of field with a blurred background', 'Everything is in sharp focus', 'A darker image', 'Longer exposure time'], 0],
    ['Which shutter speed is best to freeze a running dog?', ['1/1000 s', '1/4 s', '1 s', '1/15 s'], 0],
    ['What is the usual downside of a very high ISO?', ['More noise or grain in the image', 'Less light is captured', 'Shallower depth of field', 'Slower shutter speeds'], 0],
    ['What does the rule of thirds suggest?', ['Place key subjects along the grid lines or intersections', 'Always centre the subject', 'Use three lights', 'Take three shots of every scene'], 0],
    ['What is golden hour?', ['The period shortly after sunrise or before sunset with soft, warm light', 'Noon, when light is strongest', 'The first hour after midnight', 'Any time under studio lights'], 0],
    ['What does white balance correct?', ['The colour cast so whites look neutral', 'The sharpness of the image', 'The size of the file', 'The depth of field'], 0],
    ['Why do many photographers shoot RAW instead of JPEG?', ['RAW keeps more image data for editing', 'RAW files are always smaller', 'RAW needs no editing', 'RAW works only on phones'], 0],
    ['Which focal length gives the widest field of view?', ['24 mm', '85 mm', '200 mm', '400 mm'], 0],
    ['What are leading lines?', ['Lines in a scene that draw the viewer\'s eye toward the subject', 'The lines in a viewfinder', 'Cables used in studios', 'Borders added in editing'], 0],
    ['A histogram bunched hard against the right edge usually suggests what?', ['The image is overexposed', 'The image is underexposed', 'The image is perfectly exposed', 'The image is out of focus'], 0],
    ['Which aperture lets in the most light?', ['f/1.4', 'f/4', 'f/8', 'f/16'], 0],
  ],
};

export const skillGroups = [
  { label: 'Tech', skills: ['Web Development', 'JavaScript', 'React.js', 'Python', 'Data Science', 'Excel'] },
  { label: 'Creative', skills: ['Graphic Design', 'UI/UX Design', 'Photography'] },
  { label: 'Communication', skills: ['Public Speaking'] },
];

export const quizBank = Object.fromEntries(
  Object.entries(RAW).map(([skill, qs]) => [skill, qs.map(([q, options, answer]) => ({ q, options, answer }))])
);

// Typed topics that mean the same as a skill we have a test for.
const ALIASES = {
  'Web Development': ['web dev', 'web', 'html', 'css', 'html css', 'frontend', 'front end', 'website development'],
  JavaScript: ['js', 'ecmascript'],
  'React.js': ['react', 'reactjs'],
  Python: ['python3', 'python basics'],
  'Data Science': ['data analysis', 'data analytics'],
  Excel: ['ms excel', 'microsoft excel', 'spreadsheets', 'spreadsheet'],
  'Graphic Design': ['graphics'],
  'UI/UX Design': ['ui', 'ux', 'ui ux', 'ux ui', 'ui design', 'ux design'],
  'Public Speaking': ['speaking', 'presentation skills', 'presentations'],
  Photography: ['photo', 'photos'],
};

const key = (s) => String(s).toLowerCase().replace(/[^a-z0-9]/g, '');
const lookup = new Map();
Object.keys(quizBank).forEach((name) => {
  lookup.set(key(name), name);
  (ALIASES[name] || []).forEach((a) => lookup.set(key(a), name));
});

/** Map whatever the user typed to a skill we can test, or null. */
export function resolveSkill(input) {
  const name = lookup.get(key(input));
  return name ? { name, questions: quizBank[name] } : null;
}

/** Skills (and aliases) containing the typed text, for suggestions while typing. */
export function matchingSkills(input) {
  const q = key(input);
  if (!q) return Object.keys(quizBank);
  return Object.keys(quizBank).filter(
    (name) => key(name).includes(q) || (ALIASES[name] || []).some((a) => key(a).includes(q))
  );
}

export const passMarkFor = (n) => Math.ceil(n * 0.7);

const shuffle = (arr) => {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
};

/** Fresh attempt: shuffled questions with shuffled options. */
export function buildQuiz(questions) {
  return shuffle(questions).map((q) => ({
    q: q.q,
    options: shuffle(q.options.map((text, i) => ({ text, correct: i === q.answer }))),
  }));
}

/** Check questions that came from the backend (10 to 15, well-formed). Returns null if unusable. */
export function validateGenerated(list) {
  if (!Array.isArray(list)) return null;
  const ok = list.filter(
    (x) =>
      x && typeof x.q === 'string' && Array.isArray(x.options) && x.options.length >= 2 &&
      x.options.every((o) => typeof o === 'string') && Number.isInteger(x.answer) && x.answer >= 0 && x.answer < x.options.length
  );
  return ok.length >= 10 ? ok.slice(0, 15) : null;
}
