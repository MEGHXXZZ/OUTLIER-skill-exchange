// Mock data. Replace with real API calls (see api.js) once the backend is ready.
export const mockUser = {
  id: "u001",
  name: "Meghavathi",
  email: "megha@outlier.com",
  isVerified: true,
  preference: "Face-to-Face",
  genderFilter: "Any",
  city: "Chikkamagaluru",
  skillsToLearn: ["Web Development"],
  availability: [{ day: "Saturday", startTime: "10:00", endTime: "12:00" }],
  teachLevel: { "Graphic Design": "Advanced" },
  learnt: ["Python Basics"],
  ongoing: ["Web Development"],
  teaching: ["Graphic Design"],
  pendingTeach: [],
  badges: ["HTML Basics", "Figma Pro", "Design Thinker"],
  reliability: 96,
  streak: 3,
};

export const mockMatches = [
  { id: 1, name: "Kayashree", teaches: "Web Development", wants: "Graphic Design", matchScore: 95, availability: "Sat 10:00 AM", isVerified: true, location: "MCE Campus", canBeFaceless: true, level: "Expert", gender: "Female", reliability: 98 },
  { id: 2, name: "Arjun", teaches: "React.js", wants: "UI Design", matchScore: 88, availability: "Sun 2:00 PM", isVerified: true, location: "Online", canBeFaceless: false, level: "Intermediate", gender: "Male", reliability: 91 },
  { id: 3, name: "Sneha", teaches: "Data Science", wants: "Public Speaking", matchScore: 82, availability: "Sat 4:00 PM", isVerified: true, location: "MCE Library", canBeFaceless: true, level: "Expert", gender: "Female", reliability: 94 },
  { id: 4, name: "Rohan", teaches: "Python", wants: "Figma", matchScore: 79, availability: "Mon 6:00 PM", isVerified: false, location: "Online", canBeFaceless: true, level: "Beginner", gender: "Male", reliability: 85 },
];

export const mockCircles = [
  { id: 1, skill: "Web Development Bootcamp", teacher: "Arjun", members: 5, maxMembers: 8, schedule: "Every Saturday, 10:00 AM", isVerified: true },
  { id: 2, skill: "UI/UX Design Circle", teacher: "Meghavathi", members: 3, maxMembers: 5, schedule: "Every Sunday, 2:00 PM", isVerified: true },
  { id: 3, skill: "Data Science Study Group", teacher: "Sneha", members: 6, maxMembers: 10, schedule: "Every Friday, 6:00 PM", isVerified: true },
];

// Demo sessions. startsAt is relative to "now" so the 30-minute cancel rule can be shown:
//  #1 starts in 3 h (cancel -> Rescue Match finds a replacement)
//  #2 starts in 26 h (cancel -> no replacement, alternative slots)
//  #3 starts in 20 min (cancel is blocked; good for demoing the live room)
export const makeInitialSessions = () => {
  const now = Date.now();
  const H = 3600e3;
  return [
    { id: 1, partner: "Kayashree", skill: "Web Development", slot: "Sat 10:00 AM", mode: "Faceless", type: "1-on-1", startsAt: now + 3 * H, status: "upcoming" },
    { id: 2, partner: "Arjun", skill: "React.js", slot: "Sun 2:00 PM", mode: "Face-to-Face", type: "1-on-1", startsAt: now + 26 * H, status: "upcoming" },
    { id: 3, partner: "Sneha", skill: "Data Science", slot: "Starting soon", mode: "Face-to-Face", type: "1-on-1", startsAt: now + 20 * 60e3, status: "upcoming" },
  ];
};

// Members who could replace a cancelled session (Rescue Match pool)
export const rescueCandidates = [
  { id: 11, name: "Arjun", skill: "Web Development", slot: "Sat 10:00 AM", score: 91, location: "MCE Campus" },
  { id: 12, name: "Sneha", skill: "Data Science", slot: "Sat 4:00 PM", score: 84, location: "Online" },
];

export const alternativeSlots = ["Sat 12:00 PM", "Sun 10:00 AM", "Mon 6:00 PM"];

export const initialHistory = [
  { id: "h1", skill: "Graphic Design", partner: "Kayashree", note: "", status: "Completed", when: "Last Sunday" },
];

// Verification questions live in quizBank.js (12 questions per skill, shuffled on every attempt).
export { quizBank } from "./quizBank";
