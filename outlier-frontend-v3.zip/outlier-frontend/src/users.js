import dummyUsers from './dummyUsers';

const norm = (s) => String(s || '').trim().toLowerCase();

export const findUserById = (id) => dummyUsers.find((u) => u._id === id);
export const findUserByName = (name) => dummyUsers.find((u) => norm(u.name) === norm(name));

const windowLabel = (w) => `${w.day} ${w.startTime} - ${w.endTime}`;

// One shape for every profile page, whether it is you or someone from the directory.
export function profileFromDirectory(u) {
  return {
    id: u._id,
    isMe: false,
    name: u.name,
    gender: u.gender,
    city: u.location.city,
    bio: u.bio,
    isVerified: !!u.isVerified,
    reliability: u.reliabilityScore,
    streak: u.streak || 0,
    teaching: u.skillsToTeach,
    learning: u.skillsToLearn,
    learnt: [],
    ongoing: [],
    pending: [],
    availability: u.availability.map(windowLabel),
    mode: u.preferences.sessionType === 'Faceless' ? 'Faceless' : 'Face-to-Face',
    badges: u.badges || [],
  };
}

export function profileFromMe(user) {
  return {
    id: 'me',
    isMe: true,
    name: user.name,
    gender: null,
    city: user.city,
    bio: '',
    isVerified: user.isVerified || user.teaching.length > 0,
    reliability: user.reliability,
    streak: user.streak,
    teaching: user.teaching.map((skill) => ({ skill, level: (user.teachLevel && user.teachLevel[skill]) || 'Intermediate' })),
    learning: user.skillsToLearn || [],
    learnt: user.learnt,
    ongoing: user.ongoing,
    pending: user.pendingTeach,
    availability: (user.availability || []).map(windowLabel),
    mode: user.preference,
    badges: user.badges,
  };
}
