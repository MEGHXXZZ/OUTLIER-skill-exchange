import { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Outlet, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { AppProvider } from './store';
import Navbar from './components/Navbar';
import Toast from './components/Toast';
import Background from './components/Background';
import Login from './pages/Login';
import Signup from './pages/Signup';
import Onboarding from './pages/Onboarding';
import Dashboard from './pages/Dashboard';
import Search from './pages/Search';
import Sessions from './pages/Sessions';
import Circles from './pages/Circles';
import Profile from './pages/Profile';

// Start every page at the top (otherwise a profile opens at the scroll position of the page you clicked from).
function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
}

function WithNav() {
  return (
    <>
      <Navbar />
      <Outlet />
    </>
  );
}

function AnimatedRoutes() {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={location.pathname}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.18 }}
      >
        <Routes location={location}>
          <Route path="/" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/onboarding" element={<Onboarding />} />
          <Route element={<WithNav />}>
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/search" element={<Search />} />
            <Route path="/sessions" element={<Sessions />} />
            <Route path="/circles" element={<Circles />} />
            <Route path="/profile/:id" element={<Profile />} />
          </Route>
        </Routes>
      </motion.div>
    </AnimatePresence>
  );
}

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <ScrollToTop />
        <Background />
        <div className="grain-overlay" />
        <div className="app-layer min-h-screen">
          <AnimatedRoutes />
        </div>
        <Toast />
      </BrowserRouter>
    </AppProvider>
  );
}
