import { useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Search as SearchIcon, ShieldCheck, EyeOff, Eye, Clock, MapPin, Star, Check, Users } from 'lucide-react';
import { Card, Chip, PrimaryButton, PageHeader, stagger, fade } from '../components/ui';
import { findMatches, toMatchProfile } from '../matching';
import UserLink from '../components/UserLink';
import { useApp } from '../store';

const levels = ['Any', 'Beginner', 'Intermediate', 'Advanced'];
const genders = [
  { value: 'Male', label: 'Men' },
  { value: 'Female', label: 'Women' },
  { value: 'Any', label: 'Any' },
];

export default function Search() {
  const { requestExchange, getRequest, user } = useApp();
  const allMatches = useMemo(() => findMatches(toMatchProfile(user)), [user]);
  const [query, setQuery] = useState('');
  const [reliableOnly, setReliableOnly] = useState(false);
  const [faceless, setFaceless] = useState(false);
  const [level, setLevel] = useState('Any');
  const [gender, setGender] = useState(user.genderFilter || 'Any'); // starts from the preference set in onboarding
  const [modeFor, setModeFor] = useState({});

  const results = allMatches
    .filter((m) => {
      const q = query.toLowerCase();
      if (q && !m.teaches.toLowerCase().includes(q) && !m.name.toLowerCase().includes(q)) return false;
      if (reliableOnly && m.reliability < 80) return false;
      if (faceless && !m.canBeFaceless) return false;
      if (level !== 'Any' && m.level !== level) return false;
      if (gender !== 'Any' && m.gender !== gender) return false;
      return true;
    })
    .sort((a, b) => b.matchScore - a.matchScore);

  return (
    <motion.div variants={stagger} initial="hidden" animate="show" className="mx-auto max-w-6xl px-6 py-12">
      <PageHeader
        eyebrow="Find a match"
        title="Meet your next skill partner"
        subtitle="Ranked by complementary skills, overlapping availability, location and reliability."
      />

      <Card className="mb-6 p-4">
        <div className="relative mb-4">
          <SearchIcon size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by skill or teacher name"
            className="w-full rounded-[10px] border border-line py-3 pl-11 pr-4 text-sm outline-none transition placeholder-muted/70 focus:border-accent"
          />
        </div>
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <span className="mr-1 flex items-center gap-1.5 text-xs font-medium uppercase tracking-wider text-muted"><Users size={14} /> Match with</span>
          {genders.map((g) => <Chip key={g.value} active={gender === g.value} onClick={() => setGender(g.value)}>{g.label}</Chip>)}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Chip active={reliableOnly} onClick={() => setReliableOnly(!reliableOnly)} icon={ShieldCheck}>Reliability 80+</Chip>
          <Chip active={faceless} onClick={() => setFaceless(!faceless)} icon={EyeOff}>Faceless sessions</Chip>
          <span className="mx-2 hidden h-6 w-px bg-line md:block" />
          {levels.map((l) => <Chip key={l} active={level === l} onClick={() => setLevel(l)}>{l === 'Any' ? 'Any level' : l}</Chip>)}
        </div>
      </Card>

      <motion.p variants={fade} className="mb-4 text-sm text-muted">
        <span className="font-semibold text-ink">{results.length}</span> {results.length === 1 ? 'match' : 'matches'}
      </motion.p>

      {results.length === 0 ? (
        <Card className="p-10 text-center">
          <p className="font-display text-3xl text-ink">No suitable match yet</p>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted">
            We will notify you the moment a teacher who fits your filters joins. Try loosening a filter in the meantime.
          </p>
          <PrimaryButton className="mt-6" onClick={() => { setQuery(''); setReliableOnly(false); setFaceless(false); setLevel('Any'); setGender('Any'); }}>
            Clear filters
          </PrimaryButton>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {results.map((m, i) => {
            const request = getRequest(m.id);
            const requested = !!request && request.status !== 'declined';
            const mode = modeFor[m.id] || 'Face-to-Face';
            return (
              <Card key={m.id} className="p-6">
                <div className="mb-5 flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <UserLink name={m.name} className="flex h-11 w-11 items-center justify-center rounded-full border border-line bg-paper font-display text-xl text-ink hover:border-accent hover:no-underline">{m.name[0]}</UserLink>
                    <div>
                      <p className="flex items-center gap-1.5 text-sm font-semibold text-ink">
                        <UserLink name={m.name} /> <ShieldCheck size={14} className="text-accent" />
                      </p>
                      <p className="text-xs text-muted">Teaches {m.teaches} &middot; {m.level}</p>
                    </div>
                  </div>
                  <span className="flex items-center gap-1 rounded-[8px] bg-accent px-2 py-1 text-xs font-medium text-white">
                    <Star size={11} /> {m.matchScore}%
                  </span>
                </div>

                {i === 0 && <p className="mb-3 text-xs font-medium uppercase tracking-wider text-accent">Best match</p>}

                <div className="mb-4 space-y-2 text-sm text-muted">
                  <p className="flex items-center gap-2"><Clock size={14} /> {m.availability}</p>
                  <p className="flex items-center gap-2"><MapPin size={14} /> {m.location}</p>
                  <p className="flex items-center gap-2"><Check size={14} /> Reliability {m.reliability}</p>
                </div>

                <div className="mb-4 flex flex-wrap gap-1.5">
                  {m.reasons.map((r) => (
                    <span key={r} className="rounded-[8px] border border-line bg-paper px-2 py-1 text-[11px] text-muted">{r}</span>
                  ))}
                </div>
                <p className="mb-4 text-xs text-muted">Wants to learn {m.wants}</p>

                <div className="mb-4 grid grid-cols-2 gap-2">
                  {['Face-to-Face', 'Faceless'].map((opt) => {
                    const disabled = opt === 'Faceless' && !m.canBeFaceless;
                    return (
                      <button
                        key={opt}
                        disabled={disabled || requested}
                        onClick={() => setModeFor({ ...modeFor, [m.id]: opt })}
                        className={`flex items-center justify-center gap-1.5 rounded-[8px] border py-2 text-xs font-medium transition disabled:opacity-40 ${
                          mode === opt ? 'border-accent bg-accent/5 text-accent' : 'border-line text-muted'
                        }`}
                      >
                        {opt === 'Faceless' ? <EyeOff size={13} /> : <Eye size={13} />} {opt}
                      </button>
                    );
                  })}
                </div>

                <PrimaryButton disabled={requested} onClick={() => requestExchange(m, mode)} className="w-full">
                  {request?.status === 'pending' ? 'Awaiting approval' : request?.status === 'accepted' ? 'Exchange scheduled' : request?.status === 'declined' ? 'Declined. Request again' : 'Request exchange'}
                </PrimaryButton>
              </Card>
            );
          })}
        </div>
      )}
    </motion.div>
  );
}
