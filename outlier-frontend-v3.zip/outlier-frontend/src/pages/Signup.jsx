import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { User, Mail, Lock, ArrowRight } from 'lucide-react';
import AuthPanel from '../components/AuthPanel';
import { PrimaryButton } from '../components/ui';
import { useApp } from '../store';

export default function Signup() {
  const navigate = useNavigate();
  const { signUp } = useApp();
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' });
  const [error, setError] = useState('');

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  const submit = (e) => {
    e.preventDefault();
    if (form.password.length < 6) return setError('Password must be at least 6 characters.');
    if (form.password !== form.confirm) return setError('Passwords do not match.');
    // Frontend demo: the password is not stored. The backend will handle real accounts.
    signUp({ name: form.name.trim(), email: form.email.trim() });
    navigate('/onboarding');
  };

  const input =
    'w-full rounded-[10px] border border-line bg-white py-3.5 pl-11 pr-4 text-sm text-ink placeholder-muted/70 outline-none transition focus:border-accent';
  const label = 'mb-2 block text-xs font-medium uppercase tracking-wider text-muted';

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <AuthPanel />
      <div className="flex items-center justify-center p-6">
        <motion.form
          onSubmit={submit}
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="w-full max-w-sm"
        >
          <p className="text-xs font-medium uppercase tracking-wider text-muted">Step 1 of 3 &middot; Account</p>
          <h2 className="font-display mt-2 text-5xl text-ink">Create your account</h2>
          <p className="mt-2 mb-8 text-sm text-muted">Next, you will set up your skills and availability.</p>

          <label className={label}>Full name</label>
          <div className="relative mb-5">
            <User size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
            <input required value={form.name} onChange={set('name')} placeholder="Your name" className={input} />
          </div>

          <label className={label}>Email</label>
          <div className="relative mb-5">
            <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
            <input type="email" required value={form.email} onChange={set('email')} placeholder="you@mce.edu" className={input} />
          </div>

          <label className={label}>Password</label>
          <div className="relative mb-5">
            <Lock size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
            <input type="password" required value={form.password} onChange={set('password')} placeholder="At least 6 characters" className={input} />
          </div>

          <label className={label}>Confirm password</label>
          <div className="relative mb-6">
            <Lock size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
            <input type="password" required value={form.confirm} onChange={set('confirm')} placeholder="Repeat your password" className={input} />
          </div>

          {error && <p className="mb-4 rounded-[8px] border border-line bg-white px-3 py-2 text-sm text-ink">{error}</p>}

          <PrimaryButton type="submit" className="w-full py-3.5">
            Continue <ArrowRight size={16} />
          </PrimaryButton>

          <p className="mt-6 text-center text-sm text-muted">
            Already have an account?{' '}
            <button type="button" onClick={() => navigate('/')} className="font-medium text-accent hover:underline">
              Sign in
            </button>
          </p>
        </motion.form>
      </div>
    </div>
  );
}
