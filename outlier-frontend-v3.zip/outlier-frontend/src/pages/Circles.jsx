import { useState } from 'react';
import { motion } from 'framer-motion';
import { Users, ShieldCheck, Plus, X, Search as SearchIcon } from 'lucide-react';
import { Card, Chip, GhostButton, Modal, PrimaryButton, PageHeader, stagger } from '../components/ui';
import UserLink from '../components/UserLink';
import { useApp } from '../store';

export default function Circles() {
  const { circles, joinCircle, createCircle } = useApp();
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [openOnly, setOpenOnly] = useState(false);
  const [form, setForm] = useState({ skill: '', schedule: '', maxMembers: 5 });

  const field = 'w-full rounded-[10px] border border-line px-4 py-3 text-sm outline-none transition placeholder-muted/70 focus:border-accent';

  const visible = circles.filter((c) => {
    const q = query.trim().toLowerCase();
    if (q && !c.skill.toLowerCase().includes(q) && !c.teacher.toLowerCase().includes(q)) return false;
    if (openOnly && c.members >= c.maxMembers) return false;
    return true;
  });

  const submit = () => {
    createCircle(form);
    setForm({ skill: '', schedule: '', maxMembers: 5 });
    setOpen(false);
  };

  return (
    <motion.div variants={stagger} initial="hidden" animate="show" className="mx-auto max-w-6xl px-6 py-12">
      <PageHeader
        eyebrow="Community circles"
        title="Learn together"
        subtitle="Group sessions where one verified teacher guides many learners."
        action={<PrimaryButton onClick={() => setOpen(true)}><Plus size={15} /> Create circle</PrimaryButton>}
      />

      <Card className="mb-6 p-4">
        <div className="relative mb-3">
          <SearchIcon size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search circles by skill or teacher"
            className="w-full rounded-[10px] border border-line py-3 pl-11 pr-4 text-sm outline-none transition placeholder-muted/70 focus:border-accent"
          />
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Chip active={openOnly} onClick={() => setOpenOnly(!openOnly)}>Open spots only</Chip>
          <span className="ml-auto text-sm text-muted">
            <span className="font-semibold text-ink">{visible.length}</span> {visible.length === 1 ? 'circle' : 'circles'}
          </span>
        </div>
      </Card>

      {visible.length === 0 && (
        <Card className="p-10 text-center">
          <p className="font-display text-3xl text-ink">No circles found</p>
          <p className="mx-auto mt-2 max-w-md text-sm text-muted">Try a different search, or start the circle yourself.</p>
          <PrimaryButton className="mt-6" onClick={() => setOpen(true)}><Plus size={15} /> Create circle</PrimaryButton>
        </Card>
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {visible.map((c) => {
          const full = c.members >= c.maxMembers;
          return (
            <Card key={c.id} className="p-6">
              <div className="mb-4 flex items-start justify-between">
                <span className="flex h-10 w-10 items-center justify-center rounded-[8px] border border-line bg-paper text-accent"><Users size={18} /></span>
                {c.isVerified && (
                  <span className="flex items-center gap-1 rounded-[8px] border border-accent/30 bg-accent/5 px-2 py-1 text-xs font-medium text-accent">
                    <ShieldCheck size={12} /> Verified
                  </span>
                )}
              </div>
              <h3 className="font-display text-2xl text-ink">{c.skill}</h3>
              <p className="mt-1 mb-5 text-sm text-muted">Led by <UserLink name={c.teacher} className="font-medium text-ink" /></p>

              <div className="mb-1 flex justify-between text-sm">
                <span className="text-muted">Members</span>
                <span className="font-semibold text-ink">{c.members}/{c.maxMembers}</span>
              </div>
              <div className="mb-3 h-1.5 rounded-full bg-line">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${(c.members / c.maxMembers) * 100}%` }}
                  transition={{ duration: 0.8 }}
                  className="h-1.5 rounded-full bg-accent"
                />
              </div>
              <p className="mb-5 text-xs text-muted">{c.schedule}</p>

              {c.joined ? (
                <GhostButton disabled className="w-full opacity-70">Joined</GhostButton>
              ) : (
                <PrimaryButton disabled={full} onClick={() => joinCircle(c.id)} className="w-full">
                  {full ? 'Circle full' : 'Join circle'}
                </PrimaryButton>
              )}
            </Card>
          );
        })}
      </div>

      <Modal open={open} onClose={() => setOpen(false)}>
        <div className="mb-6 flex items-start justify-between">
          <h2 className="font-display text-3xl text-ink">Create a circle</h2>
          <button onClick={() => setOpen(false)} className="text-muted hover:text-ink"><X size={18} /></button>
        </div>
        <div className="space-y-4">
          <input className={field} placeholder="Skill, e.g. Python for beginners" value={form.skill} onChange={(e) => setForm({ ...form, skill: e.target.value })} />
          <input className={field} placeholder="Schedule, e.g. Every Monday, 6:00 PM" value={form.schedule} onChange={(e) => setForm({ ...form, schedule: e.target.value })} />
          <div>
            <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted">Maximum learners</label>
            <input type="number" min="2" max="30" className={field} value={form.maxMembers} onChange={(e) => setForm({ ...form, maxMembers: e.target.value })} />
          </div>
        </div>
        <PrimaryButton disabled={!form.skill.trim() || !form.schedule.trim()} onClick={submit} className="mt-6 w-full">
          Create circle
        </PrimaryButton>
      </Modal>
    </motion.div>
  );
}
