import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Eye, EyeOff, Users, MapPin, ArrowRight, ArrowLeft, GraduationCap, BookOpen, CalendarDays, Plus, X } from 'lucide-react';
import { Card, Chip, GhostButton, PrimaryButton, stagger, fade } from '../components/ui';
import { quizBank } from '../mockData';
import { useApp } from '../store';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const TEACHABLE = Object.keys(quizBank);
const LEARN_SUGGESTIONS = [...new Set([...TEACHABLE, 'Photography', 'Video Editing', 'Excel', 'Figma'])];

export default function Onboarding() {
  const navigate = useNavigate();
  const { user, updateProfile } = useApp();
  const [step, setStep] = useState('profile'); // profile | prefs

  const [teach, setTeach] = useState(user.pendingTeach);
  const [learn, setLearn] = useState(user.skillsToLearn);
  const [custom, setCustom] = useState('');
  const [customTeach, setCustomTeach] = useState('');
  const [rows, setRows] = useState(
    user.availability.length ? user.availability : [{ day: 'Saturday', startTime: '10:00', endTime: '12:00' }]
  );
  const [city, setCity] = useState(user.city);
  const [preference, setPreference] = useState(user.preference);
  const [genderFilter, setGenderFilter] = useState(user.genderFilter);

  const toggle = (list, setList, item) =>
    setList(list.includes(item) ? list.filter((x) => x !== item) : [...list, item]);

  const addCustom = () => {
    const v = custom.trim();
    if (v && !learn.includes(v)) setLearn([...learn, v]);
    setCustom('');
  };

  // Any skill can be offered, not only the ones we have a test for. Typed ones wait under "Awaiting verification".
  const addCustomTeach = () => {
    const v = customTeach.trim().replace(/\s+/g, ' ');
    setCustomTeach('');
    if (!v) return;
    const existing = [...TEACHABLE, ...teach].find((k) => k.toLowerCase() === v.toLowerCase());
    const name = existing || v;
    if (user.teaching.includes(name) || teach.includes(name)) return;
    setTeach([...teach, name]);
  };

  const setRow = (i, patch) => setRows(rows.map((r, idx) => (idx === i ? { ...r, ...patch } : r)));

  const validProfile =
    learn.length > 0 && city.trim() && rows.length > 0 && rows.every((r) => r.startTime && r.endTime && r.startTime < r.endTime);

  const finish = () => {
    updateProfile({ pendingTeach: teach, skillsToLearn: learn, availability: rows, city: city.trim(), preference, genderFilter });
    navigate('/dashboard');
  };

  const field =
    'rounded-[10px] border border-line bg-white px-3 py-2.5 text-sm text-ink outline-none transition focus:border-accent';

  const modeCard = (value, Icon, hint) => (
    <button
      onClick={() => setPreference(value)}
      className={`rounded-[10px] border p-4 text-left transition ${
        preference === value ? 'border-accent bg-accent/5' : 'border-line hover:border-ink'
      }`}
    >
      <Icon size={20} className={preference === value ? 'text-accent' : 'text-muted'} />
      <p className="mt-3 text-sm font-semibold text-ink">{value}</p>
      <p className="mt-0.5 text-xs text-muted">{hint}</p>
    </button>
  );

  const progress = step === 'profile' ? 2 : 3;

  return (
    <motion.div variants={stagger} initial="hidden" animate="show" className="mx-auto max-w-2xl px-6 py-14">
      <motion.div variants={fade} className="mb-10">
        <div className="mb-3 flex gap-2">
          {[1, 2, 3].map((n) => (
            <span key={n} className={`h-1 flex-1 rounded-full ${n <= progress ? 'bg-accent' : 'bg-line'}`} />
          ))}
        </div>
        <p className="text-xs font-medium uppercase tracking-wider text-muted">
          Step {progress} of 3 &middot; {step === 'profile' ? 'Skills and availability' : 'Preferences'}
        </p>
      </motion.div>

      {step === 'profile' && (
        <>
          <motion.h1 variants={fade} className="font-display text-5xl text-ink">Set up your profile</motion.h1>
          <motion.p variants={fade} className="mt-3 mb-10 text-muted">
            Tell us what you can teach, what you want to learn and when you are free. This is how we find your matches.
          </motion.p>

          <div className="space-y-4">
            <Card className="p-6">
              <p className="mb-1 flex items-center gap-2 text-sm font-semibold text-ink"><GraduationCap size={16} className="text-accent" /> Skills you can teach</p>
              <p className="mb-4 text-xs text-muted">Optional. Each one needs a short quiz before others can book you. You take it from your dashboard.</p>
              <div className="mb-4 flex flex-wrap gap-2">
                {[...new Set([...TEACHABLE, ...teach])].map((k) => {
                  const verified = user.teaching.includes(k);
                  return (
                    <Chip key={k} active={verified || teach.includes(k)} disabled={verified} onClick={() => toggle(teach, setTeach, k)}>
                      {k}{verified ? ' (verified)' : ''}
                    </Chip>
                  );
                })}
              </div>
              <div className="flex gap-2">
                <input
                  value={customTeach}
                  onChange={(e) => setCustomTeach(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addCustomTeach(); } }}
                  placeholder="Not listed? Type a skill you can teach"
                  className={`${field} flex-1`}
                />
                <GhostButton onClick={addCustomTeach}><Plus size={14} /> Add</GhostButton>
              </div>
            </Card>

            <Card className="p-6">
              <p className="mb-4 flex items-center gap-2 text-sm font-semibold text-ink"><BookOpen size={16} className="text-accent" /> Skills you want to learn</p>
              <div className="mb-4 flex flex-wrap gap-2">
                {[...new Set([...LEARN_SUGGESTIONS, ...learn])].map((k) => (
                  <Chip key={k} active={learn.includes(k)} onClick={() => toggle(learn, setLearn, k)}>{k}</Chip>
                ))}
              </div>
              <div className="flex gap-2">
                <input
                  value={custom}
                  onChange={(e) => setCustom(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addCustom(); } }}
                  placeholder="Something else? Type a skill"
                  className={`${field} flex-1`}
                />
                <GhostButton onClick={addCustom}><Plus size={14} /> Add</GhostButton>
              </div>
              {learn.length === 0 && <p className="mt-3 text-xs text-muted">Pick at least one skill to continue.</p>}
            </Card>

            <Card className="p-6">
              <p className="mb-4 flex items-center gap-2 text-sm font-semibold text-ink"><CalendarDays size={16} className="text-accent" /> When are you free?</p>
              <div className="space-y-3">
                {rows.map((r, i) => (
                  <div key={i} className="flex flex-wrap items-center gap-2">
                    <select value={r.day} onChange={(e) => setRow(i, { day: e.target.value })} className={`${field} flex-1`}>
                      {DAYS.map((d) => <option key={d}>{d}</option>)}
                    </select>
                    <input type="time" value={r.startTime} onChange={(e) => setRow(i, { startTime: e.target.value })} className={field} />
                    <span className="text-xs text-muted">to</span>
                    <input type="time" value={r.endTime} onChange={(e) => setRow(i, { endTime: e.target.value })} className={field} />
                    {rows.length > 1 && (
                      <button onClick={() => setRows(rows.filter((_, idx) => idx !== i))} className="text-muted hover:text-ink" aria-label="Remove slot">
                        <X size={16} />
                      </button>
                    )}
                  </div>
                ))}
              </div>
              {rows.some((r) => r.startTime >= r.endTime) && <p className="mt-3 text-xs text-muted">End time must be after start time.</p>}
              <GhostButton onClick={() => setRows([...rows, { day: 'Sunday', startTime: '14:00', endTime: '16:00' }])} className="mt-4">
                <Plus size={14} /> Add another slot
              </GhostButton>
            </Card>

            <Card className="p-6">
              <p className="mb-4 flex items-center gap-2 text-sm font-semibold text-ink"><MapPin size={16} className="text-accent" /> City</p>
              <input value={city} onChange={(e) => setCity(e.target.value)} placeholder="e.g. Hassan" className={`${field} w-full`} />
            </Card>
          </div>

          <motion.div variants={fade} className="mt-8">
            <PrimaryButton disabled={!validProfile} onClick={() => setStep('prefs')} className="w-full py-3.5">
              Continue <ArrowRight size={16} />
            </PrimaryButton>
          </motion.div>
        </>
      )}

      {step === 'prefs' && (
        <>
          <motion.h1 variants={fade} className="font-display text-5xl text-ink">Your comfort, your rules</motion.h1>
          <motion.p variants={fade} className="mt-3 mb-10 text-muted">
            Decide how you want to exchange skills. You can change any of this later.
          </motion.p>

          <div className="space-y-4">
            <Card className="p-6">
              <p className="mb-4 flex items-center gap-2 text-sm font-semibold text-ink"><Eye size={16} className="text-accent" /> Session preference</p>
              <div className="grid grid-cols-2 gap-3">
                {modeCard('Face-to-Face', Eye, 'Show your face on video')}
                {modeCard('Faceless', EyeOff, 'Audio and screen share only')}
              </div>
            </Card>

            <Card className="p-6">
              <p className="mb-4 flex items-center gap-2 text-sm font-semibold text-ink"><Users size={16} className="text-accent" /> Preferred match gender</p>
              <div className="flex gap-3">
                {['Male', 'Female', 'Any'].map((g) => (
                  <button
                    key={g}
                    onClick={() => setGenderFilter(g)}
                    className={`flex-1 rounded-[8px] border py-3 text-sm font-medium transition ${
                      genderFilter === g ? 'border-accent bg-accent/5 text-accent' : 'border-line text-muted hover:border-ink hover:text-ink'
                    }`}
                  >
                    {g}
                  </button>
                ))}
              </div>
            </Card>
          </div>

          <motion.div variants={fade} className="mt-8 flex gap-3">
            <GhostButton onClick={() => setStep('profile')} className="px-5 py-3.5"><ArrowLeft size={16} /> Back</GhostButton>
            <PrimaryButton onClick={finish} className="flex-1 py-3.5">
              Finish setup <ArrowRight size={16} />
            </PrimaryButton>
          </motion.div>
        </>
      )}
    </motion.div>
  );
}
