import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Mail, Lock, ArrowRight } from 'lucide-react';
import AuthPanel from '../components/AuthPanel';
import { PrimaryButton } from '../components/ui';
import { useApp } from '../store';

export default function Login() {
  const navigate = useNavigate();
  const { signIn } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const submit = (e) => {
    e.preventDefault();
    signIn(); // demo account (Meghavathi) until the backend handles real login
    navigate('/dashboard');
  };

  const input =
    'w-full rounded-[10px] border border-line bg-white py-3.5 pl-11 pr-4 text-sm text-ink placeholder-muted/70 outline-none transition focus:border-accent';

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <AuthPanel />
      <div className="flex items-center justify-center p-6">
        <motion.form
          onSubmit={submit}
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="w-full max-w-sm"
        >
          <h2 className="font-display text-5xl text-ink">Welcome back</h2>
          <p className="mt-2 mb-8 text-sm text-muted">Sign in to continue your skill journey.</p>

          <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted">Email</label>
          <div className="relative mb-5">
            <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@mce.edu" className={input} />
          </div>

          <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted">Password</label>
          <div className="relative mb-7">
            <Lock size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
            <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Your password" className={input} />
          </div>

          <PrimaryButton type="submit" className="w-full py-3.5">
            Sign in <ArrowRight size={16} />
          </PrimaryButton>

          <p className="mt-6 text-center text-sm text-muted">
            New here?{' '}
            <button type="button" onClick={() => navigate('/signup')} className="font-medium text-accent hover:underline">
              Create an account
            </button>
          </p>
        </motion.form>
      </div>
    </div>
  );
}
