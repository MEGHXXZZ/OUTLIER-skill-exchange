import { useMemo } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  ArrowLeft, ShieldCheck, MapPin, Gauge, Flame, Clock, Eye, EyeOff, GraduationCap, BookOpen, Award, CalendarDays, Video, Plus,
} from 'lucide-react';
import { Card, GhostButton, PrimaryButton, stagger, fade } from '../components/ui';
import UserLink from '../components/UserLink';
import { findMatches, toMatchProfile } from '../matching';
import { findUserById, profileFromDirectory, profileFromMe } from '../users';
import { startsLabel } from '../time';
import { useApp } from '../store';

function Section({ icon: Icon, title, count, children }) {
  return (
    <Card className="p-6">
      <div className="mb-4 flex items-center justify-between">
        <p className="flex items-center gap-2 text-sm font-semibold text-ink"><Icon size={16} className="text-accent" /> {title}</p>
        {count !== undefined && <span className="text-xs text-muted">{count}</span>}
      </div>
      {children}
    </Card>
  );
}

const Tag = ({ children, sub }) => (
  <span className="rounded-[8px] border border-line bg-paper px-3 py-1.5 text-xs font-medium text-ink">
    {children}{sub && <span className="ml-1.5 font-normal text-muted">{sub}</span>}
  </span>
);

export default function Profile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, sessions, getRequest, requestExchange } = useApp();

  const isMe = id === 'me' || id === user.id;
  const dirUser = isMe ? null : findUserById(id);
  const p = isMe ? profileFromMe(user) : dirUser ? profileFromDirectory(dirUser) : null;

  const match = useMemo(
    () => (p && !p.isMe ? findMatches(toMatchProfile(user)).find((m) => m.id === p.id) : null),
    [p, user]
  );

  if (!p) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-16 text-center">
        <p className="font-display text-4xl text-ink">Profile not found</p>
        <p className="mt-2 text-sm text-muted">We could not find that member.</p>
        <GhostButton onClick={() => navigate('/search')} className="mt-6">Back to Find Match</GhostButton>
      </div>
    );
  }

  const together = sessions.filter((s) => s.partner.toLowerCase() === p.name.toLowerCase());
  const request = match ? getRequest(match.id) : undefined;
  const requested = !!request && request.status !== 'declined';
  const mode = user.preference === 'Faceless' && match && match.canBeFaceless ? 'Faceless' : 'Face-to-Face';

  return (
    <motion.div variants={stagger} initial="hidden" animate="show" className="mx-auto max-w-4xl px-6 py-12">
      <motion.button variants={fade} onClick={() => navigate(-1)} className="mb-6 flex items-center gap-2 text-sm text-muted transition hover:text-ink">
        <ArrowLeft size={15} /> Back
      </motion.button>

      <Card className="mb-4 p-8">
        <div className="flex flex-wrap items-start justify-between gap-6">
          <div className="flex items-center gap-5">
            <span className="flex h-20 w-20 shrink-0 items-center justify-center rounded-full border border-line bg-paper font-display text-4xl text-ink">
              {p.name[0]}
            </span>
            <div>
              <h1 className="font-display text-5xl text-ink">{p.name}</h1>
              <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-2 text-sm text-muted">
                {p.isVerified && (
                  <span className="flex items-center gap-1.5 rounded-[8px] border border-accent/30 bg-accent/5 px-2 py-1 text-xs font-medium text-accent">
                    <ShieldCheck size={13} /> Verified member
                  </span>
                )}
                {p.city && <span className="flex items-center gap-1.5"><MapPin size={14} /> {p.city}</span>}
                <span className="flex items-center gap-1.5">{p.mode === 'Faceless' ? <EyeOff size={14} /> : <Eye size={14} />} {p.mode}</span>
              </div>
            </div>
          </div>

          {p.isMe ? (
            <PrimaryButton onClick={() => navigate('/dashboard')}><Plus size={15} /> Add a skill</PrimaryButton>
          ) : (
            match && (
              <PrimaryButton disabled={requested} onClick={() => requestExchange(match, mode)}>
                {request?.status === 'pending' ? 'Awaiting approval' : request?.status === 'accepted' ? 'Exchange scheduled' : request?.status === 'declined' ? 'Declined. Request again' : 'Request exchange'}
              </PrimaryButton>
            )
          )}
        </div>

        {p.bio && <p className="mt-6 max-w-2xl leading-relaxed text-muted">{p.bio}</p>}
        {p.isMe && <p className="mt-6 text-xs text-muted">This is how other members see you.</p>}
      </Card>

      <div className="mb-4 grid grid-cols-3 gap-4">
        <Card className="flex items-center gap-3 p-5">
          <Gauge size={20} className="text-accent" />
          <div><p className="font-display text-3xl text-ink">{p.reliability}</p><p className="text-xs text-muted">Reliability</p></div>
        </Card>
        <Card className="flex items-center gap-3 p-5">
          <Flame size={20} className="text-accent" />
          <div><p className="font-display text-3xl text-ink">{p.streak}</p><p className="text-xs text-muted">Week streak</p></div>
        </Card>
        <Card className="flex items-center gap-3 p-5">
          <Award size={20} className="text-accent" />
          <div><p className="font-display text-3xl text-ink">{p.badges.length}</p><p className="text-xs text-muted">Badges</p></div>
        </Card>
      </div>

      <div className="mb-4 grid gap-4 md:grid-cols-2">
        <Section icon={GraduationCap} title="Can teach" count={p.teaching.length}>
          {p.teaching.length === 0 ? (
            <p className="text-sm text-muted">{p.isMe ? 'Verify a skill to start teaching.' : 'No verified skills yet.'}</p>
          ) : (
            <div className="flex flex-wrap gap-2">{p.teaching.map((t) => <Tag key={t.skill} sub={t.level}>{t.skill}</Tag>)}</div>
          )}
          {p.pending.length > 0 && (
            <p className="mt-4 text-xs text-muted">Awaiting verification: {p.pending.join(', ')}</p>
          )}
        </Section>

        <Section icon={BookOpen} title="Wants to learn" count={p.learning.length}>
          {p.learning.length === 0 ? (
            <p className="text-sm text-muted">Nothing listed yet.</p>
          ) : (
            <div className="flex flex-wrap gap-2">{p.learning.map((k) => <Tag key={k}>{k}</Tag>)}</div>
          )}
        </Section>
      </div>

      <div className="mb-4 grid gap-4 md:grid-cols-2">
        <Section icon={CalendarDays} title="Availability" count={p.availability.length}>
          {p.availability.length === 0 ? (
            <p className="text-sm text-muted">No availability set.</p>
          ) : (
            <div className="space-y-2">
              {p.availability.map((a) => (
                <p key={a} className="flex items-center gap-2 text-sm text-ink"><Clock size={14} className="text-muted" /> {a}</p>
              ))}
            </div>
          )}
        </Section>

        <Section icon={Award} title="Badges" count={p.badges.length}>
          {p.badges.length === 0 ? (
            <p className="text-sm text-muted">No badges yet.</p>
          ) : (
            <div className="flex flex-wrap gap-2">{p.badges.map((b) => <Tag key={b}>{b}</Tag>)}</div>
          )}
        </Section>
      </div>

      {p.isMe && (p.learnt.length > 0 || p.ongoing.length > 0) && (
        <div className="mb-4 grid gap-4 md:grid-cols-2">
          <Section icon={BookOpen} title="Learnt" count={p.learnt.length}>
            <div className="flex flex-wrap gap-2">{p.learnt.map((k) => <Tag key={k}>{k}</Tag>)}</div>
          </Section>
          <Section icon={Video} title="Ongoing" count={p.ongoing.length}>
            <div className="flex flex-wrap gap-2">{p.ongoing.map((k) => <Tag key={k}>{k}</Tag>)}</div>
          </Section>
        </div>
      )}

      {!p.isMe && together.length > 0 && (
        <Section icon={Video} title={`Your sessions with ${p.name}`} count={together.length}>
          <div className="space-y-3">
            {together.map((s) => (
              <div key={s.id} className="flex flex-wrap items-center justify-between gap-2 rounded-[10px] border border-line bg-paper px-4 py-3 text-sm">
                <span className="font-medium text-ink">{s.skill}</span>
                <span className="text-muted">{s.slot} &middot; {s.mode} &middot; {s.status === 'ended' ? 'Ended' : startsLabel(s)}</span>
              </div>
            ))}
          </div>
          <GhostButton onClick={() => navigate('/sessions')} className="mt-4">Go to Sessions</GhostButton>
        </Section>
      )}
    </motion.div>
  );
}
