import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Clock, Eye, EyeOff, UserCheck, Video, AlertTriangle, CheckCircle2, Loader2 } from 'lucide-react';
import { Card, GhostButton, PrimaryButton, PageHeader, stagger, fade } from '../components/ui';
import RescueMatchModal from '../components/RescueMatchModal';
import LiveSessionRoom from '../components/LiveSessionRoom';
import UserLink from '../components/UserLink';
import { rescueCandidates, alternativeSlots } from '../mockData';
import { LATE_CANCEL_MIN, startsLabel } from '../time';
import { useApp } from '../store';

const statusStyle = {
  Completed: 'text-accent',
  Rescued: 'text-accent',
  Scheduled: 'text-ink',
  Rescheduled: 'text-ink',
  Cancelled: 'text-muted',
  Declined: 'text-muted',
};

export default function Sessions() {
  const { sessions, history, requests, withdrawRequest, cancelSession, rescueSession, rescheduleSession, endSession, checkIn } = useApp();
  const [active, setActive] = useState(null); // session being cancelled
  const [live, setLive] = useState(null); // session in the live room
  const [, tick] = useState(0);

  // Keep the "starts in" labels fresh.
  useEffect(() => {
    const t = setInterval(() => tick((n) => n + 1), 30000);
    return () => clearInterval(t);
  }, []);

  const pending = requests.filter((r) => r.status === 'pending');

  const caution = (
    <p className="mt-4 flex max-w-xl items-start gap-2.5 rounded-[10px] border border-line bg-white px-4 py-3 text-sm text-ink">
      <AlertTriangle size={16} className="mt-0.5 shrink-0" />
      <span>
        <span className="font-semibold">Caution:</span> cancel at least {LATE_CANCEL_MIN} minutes before a session starts.
        Later cancellations are not allowed, and every cancellation lowers your reliability score.
      </span>
    </p>
  );

  return (
    <motion.div variants={stagger} initial="hidden" animate="show" className="mx-auto max-w-4xl px-6 py-12">
      <PageHeader
        eyebrow="Sessions"
        title="Your schedule"
        subtitle="Upcoming exchanges and a record of everything that has happened."
        note={caution}
      />

      {pending.length > 0 && (
        <>
          <motion.h2 variants={fade} className="mb-4 text-sm font-semibold text-ink">Awaiting approval</motion.h2>
          <div className="mb-10 space-y-3">
            {pending.map((r) => (
              <Card key={r.id} className="flex flex-wrap items-center justify-between gap-4 p-5">
                <div>
                  <p className="text-base font-semibold text-ink">{r.skill} with <UserLink name={r.name} /></p>
                  <div className="mt-1 flex flex-wrap items-center gap-4 text-sm text-muted">
                    <span className="flex items-center gap-1.5"><Clock size={14} /> {r.slot}</span>
                    <span className="flex items-center gap-1.5">{r.mode === 'Faceless' ? <EyeOff size={14} /> : <Eye size={14} />} {r.mode}</span>
                  </div>
                  <p className="mt-2 flex items-center gap-1.5 text-xs font-medium text-muted">
                    <Loader2 size={12} className="animate-spin" /> Waiting for {r.name} to accept
                  </p>
                </div>
                <GhostButton onClick={() => withdrawRequest(r.id)}>Withdraw</GhostButton>
              </Card>
            ))}
          </div>
        </>
      )}

      <motion.h2 variants={fade} className="mb-4 text-sm font-semibold text-ink">Upcoming</motion.h2>
      <div className="mb-12 space-y-3">
        {sessions.length === 0 && (
          <Card className="p-6 text-sm text-muted">No upcoming sessions. Find a match to book your next exchange.</Card>
        )}
        {sessions.map((s) => {
          const ended = s.status === 'ended';
          return (
            <Card key={s.id} className="flex flex-wrap items-center justify-between gap-4 p-5">
              <div>
                <p className="text-base font-semibold text-ink">{s.skill} with <UserLink name={s.partner} /></p>
                <div className="mt-1 flex flex-wrap items-center gap-4 text-sm text-muted">
                  <span className="flex items-center gap-1.5"><Clock size={14} /> {s.slot}</span>
                  <span className="flex items-center gap-1.5">{s.mode === 'Faceless' ? <EyeOff size={14} /> : <Eye size={14} />} {s.mode}</span>
                  <span>{s.type}</span>
                </div>
                <p className={`mt-2 text-xs font-medium ${ended ? 'text-accent' : 'text-muted'}`}>
                  {ended ? 'Session ended. Confirm that you attended.' : startsLabel(s)}
                </p>
              </div>

              <div className="flex flex-wrap gap-2">
                {ended ? (
                  <PrimaryButton onClick={() => checkIn(s.id)} className="py-2.5">
                    <UserCheck size={14} /> Check in
                  </PrimaryButton>
                ) : (
                  <>
                    <PrimaryButton onClick={() => setLive(s)} className="py-2.5">
                      <Video size={14} /> Join session
                    </PrimaryButton>
                    <GhostButton onClick={() => setActive(s)}>Cancel</GhostButton>
                  </>
                )}
              </div>
            </Card>
          );
        })}
      </div>

      <motion.h2 variants={fade} className="mb-4 text-sm font-semibold text-ink">Exchange history</motion.h2>
      <Card className="divide-y divide-line">
        {history.length === 0 && <p className="px-5 py-4 text-sm text-muted">Nothing here yet.</p>}
        {history.map((h) => (
          <div key={h.id} className="flex items-center justify-between px-5 py-4 text-sm">
            <div>
              <p className="text-ink">
                {h.skill} with <UserLink name={h.partner} />{h.note ? ` (${h.note})` : ''}
              </p>
              <p className="text-xs text-muted">{h.when}</p>
            </div>
            <span className={`flex items-center gap-1.5 font-medium ${statusStyle[h.status] || 'text-ink'}`}>
              {h.status === 'Completed' && <CheckCircle2 size={14} />}
              {h.status}
            </span>
          </div>
        ))}
      </Card>

      <RescueMatchModal
        session={active}
        candidates={rescueCandidates}
        alternativeSlots={alternativeSlots}
        onClose={() => setActive(null)}
        onCancelled={cancelSession}
        onRescued={rescueSession}
        onRescheduled={rescheduleSession}
      />

      {live && (
        <LiveSessionRoom
          session={live}
          onEnd={(s) => {
            endSession(s.id);
            setLive(null);
          }}
        />
      )}
    </motion.div>
  );
}
