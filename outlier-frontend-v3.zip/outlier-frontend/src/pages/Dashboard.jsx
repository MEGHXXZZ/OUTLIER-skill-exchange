import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { BookOpen, Rocket, GraduationCap, ShieldCheck, Award, Plus, Flame, Gauge } from 'lucide-react';
import { Card, GhostButton, PrimaryButton, PageHeader, stagger, fade } from '../components/ui';
import VerifyQuizModal from '../components/VerifyQuizModal';
import { useApp } from '../store';

function Column({ title, icon: Icon, items, empty }) {
  return (
    <Card className="p-6">
      <div className="mb-5 flex items-center justify-between">
        <p className="flex items-center gap-2 text-sm font-semibold text-ink"><Icon size={16} className="text-accent" /> {title}</p>
        <span className="text-xs text-muted">{items.length}</span>
      </div>
      <div className="flex flex-wrap gap-2">
        {items.length === 0 && <p className="text-sm text-muted">{empty}</p>}
        {items.map((s) => (
          <span key={s} className="rounded-[8px] border border-line bg-paper px-3 py-1.5 text-xs font-medium text-ink">{s}</span>
        ))}
      </div>
    </Card>
  );
}

export default function Dashboard() {
  const { user, addVerifiedSkill, addPendingSkill } = useApp();
  const navigate = useNavigate();
  const [quiz, setQuiz] = useState(false);
  const [quizSkill, setQuizSkill] = useState('');

  const stats = [
    { label: 'Skills learnt', value: user.learnt.length },
    { label: 'Ongoing', value: user.ongoing.length },
    { label: 'Teaching', value: user.teaching.length },
    { label: 'Badges', value: user.badges.length },
  ];

  return (
    <motion.div variants={stagger} initial="hidden" animate="show" className="mx-auto max-w-6xl px-6 py-12">
      <PageHeader
        eyebrow="Skill growth passport"
        title={`Hello, ${user.name.split(' ')[0]}`}
        subtitle="Everything you have learnt, are learning and can teach, in one place."
        action={
          <div className="flex items-center gap-3">
            {user.isVerified && (
              <span className="flex items-center gap-2 rounded-[8px] border border-accent/30 bg-accent/5 px-3 py-2 text-sm font-medium text-accent">
                <ShieldCheck size={15} /> Verified member
              </span>
            )}
            <GhostButton onClick={() => navigate('/profile/me')}>View profile</GhostButton>
            <PrimaryButton onClick={() => { setQuizSkill(''); setQuiz(true); }}><Plus size={15} /> Add a skill</PrimaryButton>
          </div>
        }
      />

      <div className="mb-6 grid grid-cols-2 gap-4 md:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.label} className="p-5">
            <p className="font-display text-5xl text-ink">{s.value}</p>
            <p className="mt-1 text-sm text-muted">{s.label}</p>
          </Card>
        ))}
      </div>

      <div className="mb-6 grid gap-4 md:grid-cols-2">
        <Card className="flex items-center gap-4 p-5">
          <Gauge size={20} className="text-accent" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-ink">Reliability score</p>
            <div className="mt-2 h-1.5 rounded-full bg-line">
              <motion.div initial={{ width: 0 }} animate={{ width: `${user.reliability}%` }} transition={{ duration: 0.8 }} className="h-1.5 rounded-full bg-accent" />
            </div>
          </div>
          <p className="font-display text-3xl text-ink">{user.reliability}</p>
        </Card>
        <Card className="flex items-center gap-4 p-5">
          <Flame size={20} className="text-accent" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-ink">Regularity streak</p>
            <p className="text-xs text-muted">Consecutive weeks with an attended session</p>
          </div>
          <p className="font-display text-3xl text-ink">{user.streak}</p>
        </Card>
      </div>

      <div className="mb-6 grid gap-4 md:grid-cols-3">
        <Column title="Learnt" icon={BookOpen} items={user.learnt} empty="Nothing completed yet." />
        <Column title="Ongoing" icon={Rocket} items={user.ongoing} empty="No ongoing sessions." />
        <Column title="Teach / exchange" icon={GraduationCap} items={user.teaching} empty="Verify a skill to start teaching." />
      </div>

      {user.pendingTeach.length > 0 && (
        <Card className="mb-6 p-6">
          <p className="mb-1 flex items-center gap-2 text-sm font-semibold text-ink"><ShieldCheck size={16} className="text-accent" /> Awaiting verification</p>
          <p className="mb-4 text-xs text-muted">Pass a short test to start teaching these skills. Others cannot book you for them until you do.</p>
          <div className="space-y-2">
            {user.pendingTeach.map((k) => (
              <div key={k} className="flex items-center justify-between rounded-[10px] border border-line bg-paper px-4 py-3">
                <span className="text-sm font-medium text-ink">{k}</span>
                <GhostButton onClick={() => { setQuizSkill(k); setQuiz(true); }} className="py-2">Take test</GhostButton>
              </div>
            ))}
          </div>
        </Card>
      )}

      <Card className="p-6">
        <p className="mb-5 flex items-center gap-2 text-sm font-semibold text-ink"><Award size={16} className="text-accent" /> Badges earned</p>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {user.badges.map((b, i) => (
            <motion.div
              key={`${b}-${i}`}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 + i * 0.04 }}
              className="rounded-[10px] border border-line bg-paper p-5 text-center"
            >
              <Award size={22} className="mx-auto text-accent" />
              <p className="mt-3 text-sm font-medium text-ink">{b}</p>
            </motion.div>
          ))}
        </div>
      </Card>

      <VerifyQuizModal open={quiz} initialSkill={quizSkill} onClose={() => setQuiz(false)} onVerified={addVerifiedSkill} onPending={addPendingSkill} />
    </motion.div>
  );
}
