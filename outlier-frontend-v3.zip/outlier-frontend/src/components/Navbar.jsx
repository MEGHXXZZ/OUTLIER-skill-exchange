import { Link, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, Search, CalendarDays, Users, LogOut } from 'lucide-react';
import { motion } from 'framer-motion';
import { useApp } from '../store';
import NotificationBell from './NotificationBell';

const navItems = [
  { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/search', label: 'Find Match', icon: Search },
  { path: '/sessions', label: 'Sessions', icon: CalendarDays },
  { path: '/circles', label: 'Circles', icon: Users },
];

export default function Navbar() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { user } = useApp();

  return (
    <nav className="sticky top-0 z-50 border-b border-line bg-paper/85 backdrop-blur-md">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-6">
        <Link to="/dashboard" className="flex items-center gap-3">
          <span className="flex h-8 w-8 items-center justify-center rounded-[8px] bg-ink font-display text-lg text-white">O</span>
          <span className="text-sm font-semibold tracking-[0.18em] text-ink">OUTLIER</span>
        </Link>

        <div className="hidden items-center gap-1 md:flex">
          {navItems.map(({ path, label, icon: Icon }) => {
            const active = pathname === path;
            return (
              <Link key={path} to={path} className="relative px-4 py-2">
                {active && (
                  <motion.span
                    layoutId="navbar-indicator"
                    className="absolute inset-0 rounded-[8px] border border-line bg-white"
                    transition={{ type: 'spring', stiffness: 380, damping: 35 }}
                  />
                )}
                <span className={`relative flex items-center gap-2 text-sm font-medium ${active ? 'text-ink' : 'text-muted hover:text-ink'}`}>
                  <Icon size={15} />
                  {label}
                </span>
              </Link>
            );
          })}
        </div>

        <div className="flex items-center gap-3">
          <NotificationBell />
          <Link to="/profile/me" className="group flex items-center gap-2.5" aria-label="My profile">
            <span className="flex h-8 w-8 items-center justify-center rounded-full border border-line bg-white text-xs font-semibold text-ink transition group-hover:border-accent">
              {user.name[0]}
            </span>
            <span className="hidden text-sm font-medium text-ink transition group-hover:text-accent md:block">{user.name}</span>
          </Link>
          <button onClick={() => navigate('/')} className="text-muted transition hover:text-ink" aria-label="Sign out">
            <LogOut size={16} />
          </button>
        </div>
      </div>
      {/* mobile nav */}
      <div className="flex justify-around border-t border-line md:hidden">
        {navItems.map(({ path, label, icon: Icon }) => (
          <Link key={path} to={path} className={`flex flex-col items-center gap-1 py-2 text-[11px] ${pathname === path ? 'text-accent' : 'text-muted'}`}>
            <Icon size={16} />
            {label}
          </Link>
        ))}
      </div>
    </nav>
  );
}
