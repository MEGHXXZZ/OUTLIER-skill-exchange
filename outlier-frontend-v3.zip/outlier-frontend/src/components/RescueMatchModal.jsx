import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { X, Loader2, CheckCircle2, CalendarX, Clock, MapPin, AlertTriangle } from 'lucide-react';
import { Modal, PrimaryButton, GhostButton } from './ui';
import { LATE_CANCEL_MIN, minutesUntil } from '../time';
import UserLink from './UserLink';

const REASONS = [
  'Unexpected emergency',
  'Exam or assignment clash',
  'Health reasons',
  'Network or power issue',
  'Schedule conflict',
];

export default function RescueMatchModal({ session, candidates, alternativeSlots, onClose, onCancelled, onRescued, onRescheduled }) {
  const [step, setStep] = useState('reason'); // reason | searching | found | none
  const [reason, setReason] = useState('');
  const [match, setMatch] = useState(null);

  useEffect(() => {
    setStep(session && minutesUntil(session) < LATE_CANCEL_MIN ? 'late' : 'reason');
    setReason('');
    setMatch(null);
  }, [session]);

  if (!session) return null;

  const confirmCancel = () => {
    onCancelled(session.id, reason);
    setStep('searching');
    setTimeout(() => {
      const found = candidates.find((c) => c.skill === session.skill && c.slot === session.slot);
      if (found) { setMatch(found); setStep('found'); } else setStep('none');
    }, 2200);
  };

  return (
    <Modal open={!!session} onClose={onClose} locked={step === 'searching'}>
      <div className="mb-6 flex items-start justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-muted">Cancel session</p>
          <h2 className="font-display mt-1 text-3xl text-ink">{session.skill} with <UserLink name={session.partner} /></h2>
          <p className="mt-1 text-sm text-muted">{session.slot}</p>
        </div>
        {step !== 'searching' && <button onClick={onClose} className="text-muted hover:text-ink"><X size={18} /></button>}
      </div>

      <AnimatePresence mode="wait">
        {step === 'late' && (
          <motion.div key="late" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
            <p className="mb-3 flex items-center gap-2 text-sm font-medium text-ink"><AlertTriangle size={16} /> Too late to cancel</p>
            <p className="text-sm leading-relaxed text-muted">
              This session starts in {Math.max(minutesUntil(session), 0)} minutes. Cancellations must be made at least {LATE_CANCEL_MIN} minutes
              before the start time. You can still join the session, or message {session.partner} to agree on a new time.
            </p>
            <GhostButton onClick={onClose} className="mt-6 w-full">Close</GhostButton>
          </motion.div>
        )}

        {step === 'reason' && (
          <motion.div key="reason" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <p className="mb-1 text-sm font-medium text-ink">Select a valid reason</p>
            <p className="mb-3 text-xs text-muted">Sessions must be cancelled at least {LATE_CANCEL_MIN} minutes before they start. Each cancellation lowers your reliability score.</p>
            <div className="space-y-2">
              {REASONS.map((r) => (
                <button
                  key={r}
                  onClick={() => setReason(r)}
                  className={`w-full rounded-[8px] border px-4 py-3 text-left text-sm transition ${
                    reason === r ? 'border-accent bg-accent/5 text-accent' : 'border-line text-ink hover:border-muted'
                  }`}
                >
                  {r}
                </button>
              ))}
            </div>
            <div className="mt-6 flex gap-3">
              <GhostButton onClick={onClose} className="flex-1">Keep session</GhostButton>
              <PrimaryButton disabled={!reason} onClick={confirmCancel} className="flex-1">Cancel session</PrimaryButton>
            </div>
          </motion.div>
        )}

        {step === 'searching' && (
          <motion.div key="searching" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="py-10 text-center">
            <Loader2 size={28} className="mx-auto animate-spin text-accent" />
            <p className="font-display mt-4 text-2xl text-ink">Finding a replacement</p>
            <p className="mt-1 text-sm text-muted">Checking members with the same skill and time slot.</p>
          </motion.div>
        )}

        {step === 'found' && match && (
          <motion.div key="found" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
            <p className="mb-4 flex items-center gap-2 text-sm font-medium text-accent"><CheckCircle2 size={16} /> Replacement found</p>
            <div className="rounded-[10px] border border-line bg-paper p-4">
              <div className="flex items-center justify-between">
                <p className="text-base font-semibold text-ink"><UserLink name={match.name} /></p>
                <span className="rounded-[8px] bg-accent px-2 py-1 text-xs font-medium text-white">{match.score}% match</span>
              </div>
              <div className="mt-3 space-y-1.5 text-sm text-muted">
                <p className="flex items-center gap-2"><Clock size={14} /> {match.slot}</p>
                <p className="flex items-center gap-2"><MapPin size={14} /> {match.location}</p>
              </div>
            </div>
            <div className="mt-6 flex gap-3">
              <GhostButton onClick={onClose} className="flex-1">Decline</GhostButton>
              <PrimaryButton onClick={() => { onRescued(match); onClose(); }} className="flex-1">Send request</PrimaryButton>
            </div>
          </motion.div>
        )}

        {step === 'none' && (
          <motion.div key="none" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
            <p className="mb-4 flex items-center gap-2 text-sm font-medium text-ink"><CalendarX size={16} /> No one is free at this time</p>
            <p className="mb-3 text-sm text-muted">Reschedule with {session.partner} using one of these slots:</p>
            <div className="space-y-2">
              {alternativeSlots.map((slot) => (
                <button
                  key={slot}
                  onClick={() => { onRescheduled(session, slot); onClose(); }}
                  className="w-full rounded-[8px] border border-line px-4 py-3 text-left text-sm text-ink transition hover:border-accent hover:text-accent"
                >
                  {slot}
                </button>
              ))}
            </div>
            <GhostButton onClick={onClose} className="mt-4 w-full">Close</GhostButton>
          </motion.div>
        )}
      </AnimatePresence>
    </Modal>
  );
}
