import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Video, VideoOff, Mic, MicOff, Volume2, VolumeX, ScreenShare, ScreenShareOff, PhoneOff, EyeOff, AlertTriangle, CircleDot, Square } from 'lucide-react';
import { useApp } from '../store';
import UserLink from './UserLink';

const fmt = (sec) => `${String(Math.floor(sec / 60)).padStart(2, '0')}:${String(sec % 60).padStart(2, '0')}`;
const mediaOk = () => typeof navigator !== 'undefined' && !!navigator.mediaDevices && window.isSecureContext;
const INSECURE =
  'Camera, microphone and screen sharing only work on https or localhost. Open the app at http://localhost:5173 on this computer.';

const stop = (stream) => stream && stream.getTracks().forEach((t) => t.stop());

function ControlButton({ on, off, danger, onClick, icon: Icon, label, disabled, title }) {
  return (
    <div className="flex flex-col items-center gap-1.5">
      <button
        onClick={onClick}
        disabled={disabled}
        title={title}
        aria-label={label}
        className={`flex h-12 w-12 items-center justify-center rounded-[10px] border transition disabled:cursor-not-allowed disabled:opacity-30 ${
          danger ? 'border-red-500 bg-red-500 text-white' : on ? 'border-accent bg-accent text-white' : 'border-white/15 bg-white/10 text-white hover:bg-white/20'
        } ${off ? '' : ''}`}
      >
        <Icon size={20} />
      </button>
      <span className="text-[11px] text-white/60">{label}</span>
    </div>
  );
}

export default function LiveSessionRoom({ session, onEnd }) {
  const { user } = useApp();
  const faceless = session.mode === 'Faceless';

  const [seconds, setSeconds] = useState(0);
  const [cam, setCam] = useState(null);
  const [mic, setMic] = useState(null);
  const [screen, setScreen] = useState(null);
  const [speakerOn, setSpeakerOn] = useState(true);
  const [level, setLevel] = useState(0);
  const [error, setError] = useState('');

  const [recording, setRecording] = useState(false);
  const [recSeconds, setRecSeconds] = useState(0);
  const [recNote, setRecNote] = useState('');
  const recorder = useRef(null);
  const chunks = useRef([]);

  const camRef = useRef(null);
  const screenRef = useRef(null);
  const live = useRef({});
  live.current = { cam, mic, screen };

  useEffect(() => {
    const t = setInterval(() => setSeconds((s) => s + 1), 1000);
    return () => clearInterval(t);
  }, []);

  // Release camera, mic and screen when the room closes. A recording in progress is saved first.
  useEffect(() => () => {
    if (recorder.current && recorder.current.state === 'recording') recorder.current.stop();
    Object.values(live.current).forEach(stop);
  }, []);

  useEffect(() => {
    if (!recording) { setRecSeconds(0); return undefined; }
    const t = setInterval(() => setRecSeconds((s) => s + 1), 1000);
    return () => clearInterval(t);
  }, [recording]);

  useEffect(() => { if (camRef.current) camRef.current.srcObject = cam; }, [cam]);
  useEffect(() => { if (screenRef.current) screenRef.current.srcObject = screen; }, [screen]);

  // Live microphone level meter.
  useEffect(() => {
    if (!mic) { setLevel(0); return undefined; }
    const Ctx = window.AudioContext || window.webkitAudioContext;
    const ctx = new Ctx();
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 256;
    ctx.createMediaStreamSource(mic).connect(analyser);
    const buf = new Uint8Array(analyser.frequencyBinCount);
    const timer = setInterval(() => {
      analyser.getByteFrequencyData(buf);
      const avg = buf.reduce((a, b) => a + b, 0) / buf.length;
      setLevel(Math.min(1, avg / 70));
    }, 100);
    return () => { clearInterval(timer); ctx.close(); };
  }, [mic]);

  const toggleCam = async () => {
    if (cam) { stop(cam); setCam(null); return; }
    if (!mediaOk()) { setError(INSECURE); return; }
    try {
      setCam(await navigator.mediaDevices.getUserMedia({ video: true }));
      setError('');
    } catch {
      setError('Camera access was blocked or no camera was found. Allow it in the address bar and try again.');
    }
  };

  const toggleMic = async () => {
    if (mic) { stop(mic); setMic(null); return; }
    if (!mediaOk()) { setError(INSECURE); return; }
    try {
      setMic(await navigator.mediaDevices.getUserMedia({ audio: true }));
      setError('');
    } catch {
      setError('Microphone access was blocked or no microphone was found. Allow it in the address bar and try again.');
    }
  };

  const toggleScreen = async () => {
    if (screen) { stop(screen); setScreen(null); return; }
    if (!mediaOk()) { setError(INSECURE); return; }
    try {
      const s = await navigator.mediaDevices.getDisplayMedia({ video: true });
      s.getVideoTracks()[0].addEventListener('ended', () => setScreen(null));
      setScreen(s);
      setError('');
    } catch {
      setError('Screen sharing was cancelled or blocked.');
    }
  };

  // Records what you are sending (mic, and camera or shared screen) and saves it as a file when you stop.
  const startRecording = () => {
    if (typeof MediaRecorder === 'undefined') { setError('Recording is not supported in this browser. Try Chrome or Edge.'); return; }
    const tracks = [];
    if (screen) tracks.push(...screen.getVideoTracks());
    else if (cam) tracks.push(...cam.getVideoTracks());
    if (mic) tracks.push(...mic.getAudioTracks());
    if (tracks.length === 0) {
      setError('Turn on your microphone, camera or screen share first. The recording captures what you are sending.');
      return;
    }
    const stream = new MediaStream(tracks);
    const hasVideo = stream.getVideoTracks().length > 0;
    const mime = (hasVideo ? ['video/webm;codecs=vp9,opus', 'video/webm'] : ['audio/webm;codecs=opus', 'audio/webm']).find((t) => MediaRecorder.isTypeSupported(t));
    const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
    chunks.current = [];
    rec.ondataavailable = (e) => { if (e.data.size) chunks.current.push(e.data); };
    rec.onstop = () => {
      setRecording(false);
      const blob = new Blob(chunks.current, { type: rec.mimeType || 'video/webm' });
      chunks.current = [];
      if (!blob.size) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${session.skill}-with-${session.partner}-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, '-')}.webm`.replace(/\s+/g, '-');
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 10000);
      setRecNote('Recording saved to your downloads.');
    };
    rec.start(1000);
    recorder.current = rec;
    setRecording(true);
    setRecNote('');
    setError('');
  };

  const toggleRecording = () => {
    if (recording) recorder.current?.stop();
    else startRecording();
  };

  const testSpeaker = () => {
    if (!speakerOn) return;
    const Ctx = window.AudioContext || window.webkitAudioContext;
    const ctx = new Ctx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    gain.gain.value = 0.08;
    osc.frequency.value = 523;
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.45);
    osc.onended = () => ctx.close();
  };

  const selfTile = (
    <div className="relative aspect-video overflow-hidden rounded-[12px] border border-white/10 bg-[#1d1d1d]">
      {cam ? (
        <video ref={camRef} autoPlay muted playsInline className="h-full w-full -scale-x-100 object-cover" />
      ) : (
        <div className="flex h-full flex-col items-center justify-center gap-2 text-white/60">
          <span className="flex h-16 w-16 items-center justify-center rounded-full border border-white/15 font-display text-3xl text-white">{user.name[0]}</span>
          <span className="text-xs">{faceless ? 'Faceless session: camera stays off' : 'Camera is off'}</span>
        </div>
      )}
      <div className="absolute bottom-3 left-3 flex items-center gap-2 rounded-[8px] bg-black/50 px-2.5 py-1.5 text-xs text-white">
        You
        {mic ? (
          <span className="flex h-3 w-10 items-center overflow-hidden rounded-full bg-white/20">
            <span className="h-full bg-accent transition-all" style={{ width: `${Math.max(6, level * 100)}%`, background: '#4ade80' }} />
          </span>
        ) : (
          <MicOff size={12} className="text-white/60" />
        )}
      </div>
    </div>
  );

  const partnerTile = (
    <div className="relative aspect-video overflow-hidden rounded-[12px] border border-white/10 bg-[#1d1d1d]">
      <div className="flex h-full flex-col items-center justify-center gap-2 text-white/60">
        <span className="flex h-16 w-16 items-center justify-center rounded-full border border-white/15 font-display text-3xl text-white">{session.partner[0]}</span>
        <span className="text-xs">Demo view: {session.partner}'s video appears here once the call backend is connected</span>
      </div>
      <div className="absolute bottom-3 left-3 rounded-[8px] bg-black/50 px-2.5 py-1.5 text-xs text-white"><UserLink name={session.partner} newTab hoverColor="hover:text-white/70" /></div>
    </div>
  );

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.25 }}
      className="fixed inset-0 z-[150] flex flex-col bg-ink p-4 text-white md:p-6"
    >
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-white/50">Live session</p>
          <h2 className="font-display text-3xl">{session.skill} with <UserLink name={session.partner} newTab hoverColor="hover:text-white/70" /></h2>
        </div>
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 rounded-[8px] border border-white/15 px-3 py-1.5 text-xs text-white/80">
            {faceless && <EyeOff size={13} />} {session.mode}
          </span>
          {recording && (
            <span className="flex items-center gap-2 rounded-[8px] border border-red-500/60 px-3 py-1.5 text-xs font-medium text-red-300">
              <span className="h-2 w-2 animate-pulse rounded-full bg-red-500" /> REC {fmt(recSeconds)}
            </span>
          )}
          <span className="rounded-[8px] bg-white/10 px-3 py-1.5 font-mono text-sm">{fmt(seconds)}</span>
        </div>
      </div>

      {error && (
        <p className="mb-4 flex items-start gap-2 rounded-[10px] border border-white/15 bg-white/5 px-4 py-3 text-sm text-white/90">
          <AlertTriangle size={16} className="mt-0.5 shrink-0" /> {error}
        </p>
      )}

      {recNote && !recording && (
        <p className="mb-4 rounded-[10px] border border-white/15 bg-white/5 px-4 py-3 text-sm text-white/90">{recNote}</p>
      )}

      <div className="min-h-0 flex-1 overflow-y-auto">
        {screen ? (
          <div className="grid gap-4 lg:grid-cols-[1fr_260px]">
            <div className="overflow-hidden rounded-[12px] border border-white/10 bg-black">
              <video ref={screenRef} autoPlay muted playsInline className="max-h-[60vh] w-full object-contain" />
              <p className="border-t border-white/10 px-3 py-2 text-xs text-white/60">You are sharing your screen</p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1">{selfTile}{partnerTile}</div>
          </div>
        ) : (
          <div className="mx-auto grid max-w-5xl gap-4 md:grid-cols-2">{selfTile}{partnerTile}</div>
        )}
      </div>

      <div className="mt-4 flex flex-wrap items-start justify-center gap-4 border-t border-white/10 pt-4">
        <ControlButton
          on={!!cam}
          onClick={toggleCam}
          icon={cam ? Video : VideoOff}
          label={cam ? 'Camera on' : 'Camera off'}
          disabled={faceless}
          title={faceless ? 'Faceless session: camera is disabled' : undefined}
        />
        <ControlButton on={!!mic} onClick={toggleMic} icon={mic ? Mic : MicOff} label={mic ? 'Mic on' : 'Mic off'} />
        <ControlButton on={speakerOn} onClick={() => setSpeakerOn(!speakerOn)} icon={speakerOn ? Volume2 : VolumeX} label={speakerOn ? 'Speaker on' : 'Speaker off'} />
        <ControlButton on={!!screen} onClick={toggleScreen} icon={screen ? ScreenShareOff : ScreenShare} label={screen ? 'Stop sharing' : 'Share screen'} />
        <ControlButton
          danger={recording}
          onClick={toggleRecording}
          icon={recording ? Square : CircleDot}
          label={recording ? 'Stop recording' : 'Record'}
          title="Records your mic, camera or shared screen"
        />
        <div className="flex flex-col items-center gap-1.5">
          <button
            onClick={testSpeaker}
            disabled={!speakerOn}
            className="flex h-12 items-center rounded-[10px] border border-white/15 px-4 text-sm text-white/80 transition hover:bg-white/10 disabled:opacity-30"
          >
            Test speaker
          </button>
          <span className="text-[11px] text-white/60">Plays a short tone</span>
        </div>
        <div className="flex flex-col items-center gap-1.5">
          <button
            onClick={() => onEnd(session)}
            className="flex h-12 items-center gap-2 rounded-[10px] bg-white px-5 text-sm font-medium text-ink transition hover:bg-white/90"
          >
            <PhoneOff size={18} /> End session
          </button>
          <span className="text-[11px] text-white/60">Check-in unlocks after</span>
        </div>
      </div>
    </motion.div>
  );
}
