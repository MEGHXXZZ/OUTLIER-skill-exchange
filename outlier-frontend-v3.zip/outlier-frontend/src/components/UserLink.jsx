import { Link } from 'react-router-dom';
import { useApp } from '../store';
import { findUserByName } from '../users';

/**
 * A person's name that opens their profile.
 * Falls back to plain text if we have no profile for that name.
 * Use newTab where leaving the page would be disruptive (e.g. the live session room).
 */
export default function UserLink({ name, children, className = '', hoverColor = 'hover:text-accent', newTab = false }) {
  const { user } = useApp();
  const isMe = String(name).trim().toLowerCase() === user.name.trim().toLowerCase();
  const other = isMe ? null : findUserByName(name);
  const label = children ?? name;
  if (!isMe && !other) return <>{label}</>;

  return (
    <Link
      to={isMe ? '/profile/me' : `/profile/${other._id}`}
      {...(newTab ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
      className={`underline-offset-4 transition hover:underline ${hoverColor} ${className}`}
    >
      {label}
    </Link>
  );
}
