import { motion } from 'framer-motion';

export const ease = [0.16, 1, 0.3, 1];

export const stagger = { hidden: {}, show: { transition: { staggerChildren: 0.04 } } };
export const fade = {
  hidden: { opacity: 0, y: 12 },
  show: { opacity: 1, y: 0, transition: { duration: 0.45, ease } },
};

export function PageHeader({ eyebrow, title, subtitle, note, action }) {
  return (
    <motion.div variants={fade} className="mb-10 flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className="text-xs font-medium uppercase tracking-wider text-muted">{eyebrow}</p>
        <h1 className="font-display mt-2 text-5xl text-ink">{title}</h1>
        {subtitle && <p className="mt-2 max-w-xl text-muted">{subtitle}</p>}
        {note}
      </div>
      {action}
    </motion.div>
  );
}

export function PrimaryButton({ children, className = '', ...props }) {
  return (
    <motion.button
      whileTap={{ scale: 0.98 }}
      className={`inline-flex items-center justify-center gap-2 rounded-[8px] bg-accent px-5 py-3 text-sm font-medium text-white transition hover:bg-[#183b2c] disabled:cursor-not-allowed disabled:opacity-40 ${className}`}
      {...props}
    >
      {children}
    </motion.button>
  );
}

export function GhostButton({ children, className = '', ...props }) {
  return (
    <motion.button
      whileTap={{ scale: 0.98 }}
      className={`inline-flex items-center justify-center gap-2 rounded-[8px] border border-line bg-white px-4 py-2.5 text-sm font-medium text-ink transition hover:border-ink ${className}`}
      {...props}
    >
      {children}
    </motion.button>
  );
}

export function Card({ children, className = '', ...props }) {
  return (
    <motion.div variants={fade} className={`rounded-[12px] border border-line bg-white ${className}`} {...props}>
      {children}
    </motion.div>
  );
}

export function Chip({ active, onClick, children, icon: Icon, disabled }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`inline-flex items-center gap-2 rounded-[8px] border px-3.5 py-2.5 text-sm font-medium transition ${
        active ? 'border-accent bg-accent/5 text-accent' : 'border-line bg-white text-muted hover:border-ink hover:text-ink'
      } disabled:cursor-default`}
    >
      {Icon && <Icon size={15} />}
      {children}
    </button>
  );
}

export function Modal({ open, onClose, children, locked = false, size = 'md' }) {
  if (!open) return null;
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.2 }}
      className="fixed inset-0 z-[100] flex items-center justify-center bg-ink/40 p-4"
      onClick={locked ? undefined : onClose}
    >
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, ease }}
        onClick={(e) => e.stopPropagation()}
        className={`max-h-[90vh] w-full overflow-y-auto rounded-[12px] border border-line bg-white p-8 ${size === 'lg' ? 'max-w-xl' : 'max-w-md'}`}
      >
        {children}
      </motion.div>
    </motion.div>
  );
}
