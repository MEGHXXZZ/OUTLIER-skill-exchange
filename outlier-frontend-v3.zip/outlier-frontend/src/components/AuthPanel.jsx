import { motion } from 'framer-motion';
import { ShieldCheck, EyeOff, RefreshCw } from 'lucide-react';
import { stagger, fade } from './ui';

const points = [
  { icon: ShieldCheck, title: 'Verified skills', text: 'Pass a short test before you can teach.' },
  { icon: EyeOff, title: 'Your comfort first', text: 'Choose face or faceless sessions.' },
  { icon: RefreshCw, title: 'Rescue Match', text: 'Cancelled? We find a replacement instantly.' },
];

export default function AuthPanel() {
  return (
    <motion.div variants={stagger} initial="hidden" animate="show" className="hidden flex-col justify-between border-r border-line p-14 lg:flex">
      <motion.div variants={fade} className="flex items-center gap-3">
        <span className="flex h-9 w-9 items-center justify-center rounded-[8px] bg-ink font-display text-xl text-white">O</span>
        <span className="text-sm font-semibold tracking-[0.2em]">OUTLIER</span>
      </motion.div>

      <div>
        <motion.h1 variants={fade} className="font-display text-7xl leading-[1.02] text-ink">
          Trade skills,
          <br />
          <span className="text-accent italic">not money.</span>
        </motion.h1>
        <motion.p variants={fade} className="mt-6 max-w-md text-lg leading-relaxed text-muted">
          A community where people teach what they know and learn what they need, matched by skill, schedule and location.
        </motion.p>
        <div className="mt-12 space-y-6">
          {points.map(({ icon: Icon, title, text }) => (
            <motion.div variants={fade} key={title} className="flex gap-4">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-[8px] border border-line bg-white text-accent">
                <Icon size={18} />
              </span>
              <div>
                <p className="text-sm font-semibold text-ink">{title}</p>
                <p className="text-sm text-muted">{text}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <motion.p variants={fade} className="text-xs text-muted">
        Team OUTLIER &middot; CBC064 &middot; Malnad College of Engineering
      </motion.p>
    </motion.div>
  );
}
