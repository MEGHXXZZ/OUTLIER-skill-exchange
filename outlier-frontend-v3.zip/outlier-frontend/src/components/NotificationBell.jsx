import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Bell, CheckCircle2, XCircle } from 'lucide-react';
import { useApp } from '../store';

const ago = (at) => {
  const m = Math.floor((Date.now() - at) / 60000);
  if (m < 1) return 'Just now';
  if (m < 60) return `${m} min ago`;
  return `${Math.floor(m / 60)} h ago`;
};

export default function NotificationBell() {
  const { notifications, markNotificationsRead } = useApp();
  const [open, setOpen] = useState(false);
  const unread = notifications.filter((n) => !n.read).length;

  const close = () => {
    setOpen(false);
    markNotificationsRead();
  };

  return (
    <div className="relative">
      <button
        onClick={() => (open ? close() : setOpen(true))}
        className="relative flex h-8 w-8 items-center justify-center rounded-full text-muted transition hover:text-ink"
        aria-label={`Notifications${unread ? `, ${unread} unread` : ''}`}
      >
        <Bell size={17} />
        {unread > 0 && (
          <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-accent px-1 text-[10px] font-semibold text-white">
            {unread}
          </span>
        )}
      </button>

      <AnimatePresence>
        {open && (
          <>
            <div className="fixed inset-0 z-[60]" onClick={close} />
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.15 }}
              className="absolute right-0 top-full z-[70] mt-2 w-80 max-w-[calc(100vw-2rem)] overflow-hidden rounded-[12px] border border-line bg-white"
            >
              <p className="border-b border-line px-4 py-3 text-sm font-semibold text-ink">Notifications</p>
              {notifications.length === 0 ? (
                <p className="px-4 py-6 text-sm text-muted">Nothing yet. Replies to your exchange requests show up here.</p>
              ) : (
                <ul className="max-h-80 divide-y divide-line overflow-y-auto">
                  {notifications.map((n) => (
                    <li key={n.id} className={`flex items-start gap-3 px-4 py-3 ${n.read ? '' : 'bg-accent/5'}`}>
                      {n.kind === 'declined' ? (
                        <XCircle size={16} className="mt-0.5 shrink-0 text-muted" />
                      ) : (
                        <CheckCircle2 size={16} className="mt-0.5 shrink-0 text-accent" />
                      )}
                      <div>
                        <p className="text-sm text-ink">{n.text}</p>
                        <p className="mt-0.5 text-xs text-muted">{ago(n.at)}</p>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
