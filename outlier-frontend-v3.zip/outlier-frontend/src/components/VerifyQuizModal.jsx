import { useEffect, useRef, useState } from 'react';
import { CheckCircle2, XCircle, X, Loader2, Plus, Search as SearchIcon, ArrowRight, Info } from 'lucide-react';
import { Modal, PrimaryButton, GhostButton } from './ui';
import { skillGroups, resolveSkill, matchingSkills, buildQuiz, passMarkFor, validateGenerated } from '../quizBank';
import { generateQuiz } from '../api';
import { useApp } from '../store';

// "guitar" -> "Guitar"; leaves anything with capitals (e.g. "AutoCAD") alone.
const tidy = (s) =>
  s.trim().replace(/\s+/g, ' ').split(' ').map((w) => (w === w.toLowerCase() ? w.charAt(0).toUpperCase() + w.slice(1) : w)).join(' ');

export default function VerifyQuizModal({ open, initialSkill = '', onClose, onVerified, onPending }) {
  const { user } = useApp();
  const [step, setStep] = useState('pick'); // pick | loading | quiz | result | unavailable
  const [topic, setTopic] = useState('');
  const [skill, setSkill] = useState('');
  const [error, setError] = useState('');
  const [source, setSource] = useState([]); // raw questions, kept for "Retake"
  const [quiz, setQuiz] = useState([]);
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState(null);
  const [score, setScore] = useState(0);
  const run = useRef(0); // cancels a pending lookup if the modal is closed meanwhile

  const resolved = topic.trim() ? resolveSkill(topic) : null;
  const suggestions = matchingSkills(topic);
  const total = quiz.length;
  const passMark = passMarkFor(total);
  const passed = score >= passMark;
  const isPending = user.pendingTeach.includes(skill);

  const start = (name, questions) => {
    setSkill(name);
    setSource(questions);
    setQuiz(buildQuiz(questions));
    setIndex(0);
    setSelected(null);
    setScore(0);
    setStep('quiz');
  };

  const begin = async (raw) => {
    const text = (raw ?? topic).trim();
    if (!text) return;
    const hit = resolveSkill(text);
    const name = hit ? hit.name : tidy(text);
    if (user.teaching.includes(name)) {
      setError(`You are already verified in ${name}.`);
      return;
    }
    setError('');
    if (hit) { start(name, hit.questions); return; }

    // No local test for this topic: ask the backend to generate one, otherwise tell the user honestly.
    const id = ++run.current;
    setSkill(name);
    setStep('loading');
    try {
      const res = await generateQuiz(name);
      const qs = validateGenerated(res.data && res.data.questions);
      if (id !== run.current) return;
      if (qs) { start(name, qs); return; }
    } catch {
      /* backend not available yet */
    }
    if (id === run.current) setStep('unavailable');
  };

  useEffect(() => {
    if (!open) { run.current += 1; return; }
    setTopic(initialSkill);
    setError('');
    setQuiz([]);
    if (initialSkill) begin(initialSkill);
    else setStep('pick');
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, initialSkill]);

  const next = () => {
    const gained = quiz[index].options[selected].correct ? 1 : 0;
    const newScore = score + gained;
    setScore(newScore);
    if (index + 1 < total) { setIndex(index + 1); setSelected(null); }
    else setStep('result');
  };

  const retake = () => start(skill, source);

  const close = () => { run.current += 1; onClose(); };

  const inputCls = 'w-full rounded-[10px] border border-line bg-white py-3 pl-11 pr-4 text-sm text-ink outline-none transition placeholder-muted/70 focus:border-accent';

  return (
    <Modal open={open} onClose={close} size="lg" locked={step === 'quiz' || step === 'loading'}>
      <div className="mb-6 flex items-start justify-between">
        <div>
          <p className="text-xs font-medium uppercase tracking-wider text-muted">Skill verification</p>
          <h2 className="font-display mt-1 text-3xl text-ink">
            {step === 'pick' ? 'What do you know well?' : 'Prove it before you teach it'}
          </h2>
        </div>
        <button onClick={close} className="text-muted hover:text-ink" aria-label="Close"><X size={18} /></button>
      </div>

      {step === 'pick' && (
        <div>
          <label className="mb-2 block text-xs font-medium uppercase tracking-wider text-muted">Type a topic</label>
          <div className="relative">
            <SearchIcon size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
            <input
              autoFocus
              value={topic}
              onChange={(e) => { setTopic(e.target.value); setError(''); }}
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); begin(); } }}
              placeholder="e.g. Python, Photography, Guitar"
              className={inputCls}
            />
          </div>
          {error && <p className="mt-2 text-xs text-ink">{error}</p>}

          <p className="mb-3 mt-6 text-xs font-medium uppercase tracking-wider text-muted">
            {topic.trim() ? 'Matching suggestions' : 'Suggestions'}
          </p>
          {suggestions.length === 0 ? (
            <p className="rounded-[10px] border border-line bg-paper px-4 py-3 text-sm text-muted">
              No suggestion matches &ldquo;{topic.trim()}&rdquo;. You can still use it as your own topic below.
            </p>
          ) : (
            <div className="space-y-4">
              {skillGroups.map((g) => {
                const list = g.skills.filter((k) => suggestions.includes(k));
                if (list.length === 0) return null;
                return (
                  <div key={g.label}>
                    <p className="mb-2 text-[11px] text-muted">{g.label}</p>
                    <div className="flex flex-wrap gap-2">
                      {list.map((k) => {
                        const done = user.teaching.includes(k);
                        const active = resolved && resolved.name === k;
                        return (
                          <button
                            key={k}
                            disabled={done}
                            onClick={() => { setTopic(k); setError(''); }}
                            className={`rounded-[8px] border px-3.5 py-2 text-sm font-medium transition disabled:cursor-default disabled:opacity-40 ${
                              active ? 'border-accent bg-accent/5 text-accent' : 'border-line text-muted hover:border-ink hover:text-ink'
                            }`}
                          >
                            {k}{done ? ' (verified)' : ''}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {topic.trim() && !resolved && (
            <button
              onClick={() => begin()}
              className="mt-4 flex w-full items-center gap-2 rounded-[10px] border border-dashed border-line px-4 py-3 text-left text-sm text-ink transition hover:border-accent hover:text-accent"
            >
              <Plus size={15} /> Use &ldquo;{tidy(topic)}&rdquo; as my own topic
            </button>
          )}

          <p className="mt-6 flex items-start gap-2 text-xs text-muted">
            <Info size={14} className="mt-0.5 shrink-0" />
            {resolved
              ? `${resolved.questions.length} questions, you need ${passMarkFor(resolved.questions.length)} correct to pass. Questions and answers are shuffled each attempt.`
              : 'Each test has 12 questions and you need 70% to pass. Questions and answers are shuffled each attempt.'}
          </p>
          <PrimaryButton disabled={!topic.trim()} onClick={() => begin()} className="mt-4 w-full">
            Start test <ArrowRight size={16} />
          </PrimaryButton>
        </div>
      )}

      {step === 'loading' && (
        <div className="py-10 text-center">
          <Loader2 size={28} className="mx-auto animate-spin text-accent" />
          <p className="font-display mt-4 text-2xl text-ink">Preparing your {skill} test</p>
          <p className="mt-1 text-sm text-muted">Looking for questions on this topic.</p>
        </div>
      )}

      {step === 'unavailable' && (
        <div>
          <p className="font-display text-2xl text-ink">No test for &ldquo;{skill}&rdquo; yet</p>
          <p className="mt-2 text-sm leading-relaxed text-muted">
            We do not have verified questions for this topic right now, so we cannot confirm it yet.
            {isPending
              ? ' It is already saved under Awaiting verification, and you can take the test as soon as it is available.'
              : ' Save it under Awaiting verification on your dashboard and take the test as soon as it is available, or pick one of the suggested skills instead.'}
          </p>
          <div className="mt-6 flex gap-3">
            <GhostButton onClick={() => setStep('pick')} className="flex-1">Choose another skill</GhostButton>
            {!isPending && (
              <PrimaryButton onClick={() => { onPending && onPending(skill); close(); }} className="flex-1">Save for later</PrimaryButton>
            )}
          </div>
        </div>
      )}

      {step === 'quiz' && quiz[index] && (
        <div>
          <div className="mb-1 flex items-center justify-between text-xs text-muted">
            <span>{skill}</span>
            <span>Question {index + 1} of {total}</span>
          </div>
          <div className="mb-6 h-1 rounded-full bg-line">
            <div className="h-1 rounded-full bg-accent transition-all" style={{ width: `${((index + 1) / total) * 100}%` }} />
          </div>
          <p className="mb-4 text-base font-semibold leading-snug text-ink">{quiz[index].q}</p>
          <div className="space-y-2">
            {quiz[index].options.map((opt, i) => (
              <button
                key={opt.text}
                onClick={() => setSelected(i)}
                className={`w-full rounded-[8px] border px-4 py-3 text-left text-sm transition ${
                  selected === i ? 'border-accent bg-accent/5 text-accent' : 'border-line text-ink hover:border-muted'
                }`}
              >
                {opt.text}
              </button>
            ))}
          </div>
          <PrimaryButton disabled={selected === null} onClick={next} className="mt-6 w-full">
            {index + 1 === total ? 'Finish test' : 'Next question'} <ArrowRight size={16} />
          </PrimaryButton>
        </div>
      )}

      {step === 'result' && (
        <div className="text-center">
          {passed ? (
            <>
              <CheckCircle2 size={36} className="mx-auto text-accent" />
              <p className="font-display mt-3 text-3xl text-ink">Verified</p>
              <p className="mt-1 text-sm text-muted">
                You scored {score}/{total}. {skill} can now appear on your profile and others can book you for it.
              </p>
              <PrimaryButton onClick={() => { onVerified(skill); close(); }} className="mt-6 w-full">
                Add to my profile
              </PrimaryButton>
            </>
          ) : (
            <>
              <XCircle size={36} className="mx-auto text-ink" />
              <p className="font-display mt-3 text-3xl text-ink">Not yet</p>
              <p className="mt-1 text-sm text-muted">
                You scored {score}/{total}. You need at least {passMark} correct to teach {skill}. Brush up and try again, the questions will be reshuffled.
              </p>
              <div className="mt-6 flex gap-3">
                <GhostButton onClick={close} className="flex-1">Close</GhostButton>
                <PrimaryButton onClick={retake} className="flex-1">Retake test</PrimaryButton>
              </div>
            </>
          )}
        </div>
      )}
    </Modal>
  );
}
