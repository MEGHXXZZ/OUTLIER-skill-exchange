import { useEffect, useRef } from 'react';

/**
 * Global animated background:
 *  - drifting aurora blobs (emerald / lime / peach / teal)
 *  - fading dot grid
 *  - cursor-following spotlight
 *  - one glowing "outlier" dot that drifts away from the grid (brand nod)
 */
export default function Background() {
  const ref = useRef(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const touch = window.matchMedia('(pointer: coarse)').matches;
    if (reduce || touch) return;

    let raf = 0;
    let x = window.innerWidth / 2;
    let y = window.innerHeight / 3;
    const onMove = (e) => {
      x = e.clientX;
      y = e.clientY;
      if (!raf) {
        raf = requestAnimationFrame(() => {
          el.style.setProperty('--mx', `${x}px`);
          el.style.setProperty('--my', `${y}px`);
          raf = 0;
        });
      }
    };
    window.addEventListener('pointermove', onMove, { passive: true });
    return () => {
      window.removeEventListener('pointermove', onMove);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div ref={ref} className="bg-stage" aria-hidden="true">
      <div className="bg-blob bg-blob-emerald" />
      <div className="bg-blob bg-blob-lime" />
      <div className="bg-blob bg-blob-peach" />
      <div className="bg-blob bg-blob-teal" />
      <div className="bg-dots" />
      <div className="bg-spot" />
      <span className="bg-outlier" />
    </div>
  );
}
