export const LATE_CANCEL_MIN = 30;

export const minutesUntil = (session) => Math.round((session.startsAt - Date.now()) / 60000);

export function startsLabel(session) {
  const m = minutesUntil(session);
  if (m <= 0) return 'Starting now';
  if (m < 60) return `Starts in ${m} min`;
  const h = Math.floor(m / 60);
  if (h < 24) return `Starts in ${h} h${m % 60 ? ` ${m % 60} min` : ''}`;
  return `Starts in ${Math.round(h / 24)} d`;
}
